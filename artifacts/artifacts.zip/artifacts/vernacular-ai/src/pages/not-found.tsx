import { ArrowLeft, CircleAlert } from 'lucide-react';
import { Link } from 'wouter';

export default function NotFound() {
  return (
    <div className="paper-grid flex min-h-[100dvh] items-center justify-center px-5">
      <div className="w-full max-w-md rounded-[24px] border border-[#ded6c7] bg-[#fffaf0] p-7 shadow-[0_18px_40px_rgba(44,47,65,.07)]">
        <div className="flex items-start gap-4">
          <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-[#fff1ec] text-[#a14b38]"><CircleAlert size={21} /></span>
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#a14b38]">404 / page missing</p>
            <h1 className="mt-2 font-display text-3xl font-semibold tracking-[-.05em] text-[#222b4b]">This lesson has not been written yet.</h1>
            <p className="mt-3 text-sm leading-6 text-[#77736c]">The page you were looking for is not part of this learning layer.</p>
          </div>
        </div>
        <Link href="/" className="mt-7 inline-flex items-center gap-2 rounded-xl bg-[#222b4b] px-4 py-3 text-sm font-bold text-[#fffaf0]" data-testid="link-back-home"><ArrowLeft size={15} />Return to overview</Link>
      </div>
    </div>
  );
}