import { useMemo, useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  ArrowRight,
  BookMarked,
  BookOpenText,
  BrainCircuit,
  Check,
  ChevronDown,
  ChevronRight,
  CircleAlert,
  CircleCheck,
  ClipboardList,
  Database,
  FileText,
  Gauge,
  GraduationCap,
  Heart,
  Home as HomeIcon,
  Layers3,
  Library,
  Lightbulb,
  ListChecks,
  Menu,
  MessageCircleQuestion,
  Mic2,
  Network,
  Play,
  RefreshCw,
  Search,
  Send,
  Settings2,
  ShieldCheck,
  Sparkles,
  ThumbsDown,
  ThumbsUp,
  Timer,
  Volume2,
  X,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import {
  getGetCurriculumChapterQueryKey,
  getHealthCheckQueryKey,
  useAskLearningQuestion,
  useGenerateLesson,
  useGetCurriculumChapter,
  useGetSystemStatus,
  useHealthCheck,
  useListCurriculum,
  useSubmitFeedback,
} from '@workspace/api-client-react';
import type {
  CurriculumChapter,
  CurriculumChapterDetail,
  LearningQuestionInputSubject,
  LearningQuestionInputTargetLanguage,
  LearningResponse,
  LessonPack,
  SystemStatusResponse,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Link, Route, Router as WouterRouter, Switch, useLocation } from 'wouter';

const queryClient = new QueryClient();

type IconType = LucideIcon;

const cn = (...parts: Array<string | false | null | undefined>) => parts.filter(Boolean).join(' ');

function Logo({ dark = false }: { dark?: boolean }) {
  return (
    <Link href="/" className="group flex items-center gap-3" data-testid="link-logo">
      <span className={cn('grid size-10 place-items-center rounded-md border text-xl font-semibold', dark ? 'border-white/15 bg-[#f7b955] text-[#222b4b]' : 'border-[#d6a23f] bg-[#f7b955] text-[#222b4b]')}>
        अ
      </span>
      <span className="leading-none">
        <span className={cn('block text-[17px] font-bold tracking-[-.03em]', dark ? 'text-[#fff9ed]' : 'text-[#183b63]')}>VernacularAI</span>
        <span className={cn('mt-1 block text-[9px] uppercase tracking-[.12em]', dark ? 'text-[#c9cfdf]' : 'text-[#667085]')}>Mother tongue learning</span>
      </span>
    </Link>
  );
}

const navItems: Array<{ href: string; label: string; note: string; icon: IconType }> = [
  { href: '/', label: 'Overview', note: 'Start here', icon: HomeIcon },
  { href: '/teacher', label: 'Teacher mode', note: 'Build a lesson', icon: GraduationCap },
  { href: '/student', label: 'Student mode', note: 'Ask & learn', icon: Lightbulb },
  { href: '/curriculum', label: 'Curriculum', note: 'Indexed library', icon: Library },
  { href: '/dashboard', label: 'Demo console', note: 'System view', icon: Gauge },
];

function Sidebar({ location }: { location: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <header className="sticky top-0 z-30 border-b border-[#d8e0ea] bg-white" aria-label="Main navigation">
        <div className="mx-auto flex min-h-[72px] max-w-[1280px] items-center justify-between gap-5 px-5 sm:px-8">
          <Logo />
          <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary navigation">
            {navItems.map((item) => <Link key={item.href} href={item.href} className={cn('rounded-md px-3 py-2 text-sm font-semibold', item.href === location ? 'bg-[#e8f0f8] text-[#183b63]' : 'text-[#526173] hover:bg-[#f2f5f8] hover:text-[#183b63]')} data-testid={`link-nav-${item.label.toLowerCase().replaceAll(' ', '-')}`}>{item.label === 'Demo console' ? 'System status' : item.label}</Link>)}
          </nav>
          <div className="hidden items-center gap-3 lg:flex">
            <span className="rounded-md border border-[#d8e0ea] bg-[#f7f9fb] px-3 py-2 text-xs font-semibold text-[#526173]">Learning language: Santali</span>
            <Link href="/dashboard" className="inline-flex items-center gap-2 rounded-md border border-[#c8d5e2] px-3 py-2 text-xs font-semibold text-[#183b63] hover:bg-[#f2f5f8]" data-testid="link-system-status"><CircleCheck size={14} className="text-[#2f8f83]" />System status</Link>
            <span className="grid size-9 place-items-center rounded-full bg-[#e8f0f8] text-xs font-bold text-[#183b63]" aria-label="Public demo profile">PD</span>
          </div>
          <button className="grid size-10 place-items-center rounded-md border border-[#c8d5e2] bg-white text-[#183b63] lg:hidden" onClick={() => setOpen(!open)} aria-label="Open navigation" data-testid="button-open-navigation">
            {open ? <X size={19} /> : <Menu size={19} />}
          </button>
        </div>
        {open && <div className="border-t border-[#d8e0ea] bg-white px-5 py-3 lg:hidden">
          <nav className="mx-auto grid max-w-[1280px] gap-1" aria-label="Mobile navigation">
            {navItems.map((item) => <NavItem key={item.href} item={item} active={item.href === location} onNavigate={() => setOpen(false)} light />)}
          </nav>
          <div className="mx-auto mt-3 max-w-[1280px] border-t border-[#edf0f4] pt-3 text-xs font-semibold text-[#667085]">Learning language: Santali · SIH 2026 Prototype</div>
        </div>}
      </header>
    </>
  );
}

function NavItem({ item, active, onNavigate, light = false }: { item: typeof navItems[number]; active: boolean; onNavigate?: () => void; light?: boolean }) {
  const Icon = item.icon;
  return (
    <Link href={item.href} onClick={onNavigate} className={cn('group flex items-center gap-3 rounded-xl px-3 py-3 transition-colors', active ? (light ? 'bg-[#f1e7d4] text-[#222b4b]' : 'bg-[#f7b955] text-[#222b4b]') : (light ? 'text-[#62656c] hover:bg-[#f4ecdf] hover:text-[#222b4b]' : 'text-[#b6bfd4] hover:bg-white/[.07] hover:text-[#fff9ed]'))} data-testid={`link-nav-${item.label.toLowerCase().replaceAll(' ', '-')}`}>
      <Icon size={18} strokeWidth={active ? 2.3 : 1.8} />
      <span className="min-w-0 flex-1"><span className="block text-[13px] font-semibold">{item.label}</span><span className={cn('mt-0.5 block text-[10px]', active ? (light ? 'text-[#77716a]' : 'text-[#5f4d25]') : (light ? 'text-[#99928a]' : 'text-[#8992ae]'))}>{item.note}</span></span>
      {active && <ChevronRight size={14} />}
    </Link>
  );
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <div className="noise min-h-[100dvh] bg-background text-foreground"><Sidebar location={location} /><main className="min-h-[calc(100dvh-72px)]">{children}</main></div>;
}

function Eyebrow({ children, tone = 'default' }: { children: ReactNode; tone?: 'default' | 'dark' | 'saffron' }) {
  return <div className={cn('flex items-center gap-2 font-mono text-[10px] font-bold uppercase tracking-[.2em]', tone === 'dark' ? 'text-[#98a2be]' : tone === 'saffron' ? 'text-[#a96813]' : 'text-[#6f716f]')}><span className={cn('size-1.5 rounded-full', tone === 'dark' ? 'bg-[#f7b955]' : tone === 'saffron' ? 'bg-[#f7b955]' : 'bg-[#2f8f83]')} />{children}</div>;
}

function PageHeader({ eyebrow, title, description, action }: { eyebrow: string; title: ReactNode; description?: string; action?: ReactNode }) {
  return <header className="mx-auto flex max-w-[1200px] flex-col justify-between gap-6 px-5 pb-8 pt-8 sm:px-8 md:flex-row md:items-end md:pt-12"><div><Eyebrow>{eyebrow}</Eyebrow><h1 className="mt-4 max-w-3xl font-display text-4xl font-semibold leading-[1.05] tracking-[-.055em] text-[#222b4b] sm:text-5xl">{title}</h1>{description && <p className="mt-4 max-w-2xl text-[15px] leading-7 text-[#696b70]">{description}</p>}</div>{action}</header>;
}

function SectionCard({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <section className={cn('rounded-[22px] border border-[#ded6c7] bg-[#fffaf0] shadow-[0_12px_30px_rgba(44,47,65,.04)]', className)}>{children}</section>;
}

function EmptyState({ icon: Icon, title, text }: { icon: IconType; title: string; text: string }) {
  return <div className="grid min-h-[260px] place-items-center p-8 text-center"><div><span className="mx-auto grid size-12 place-items-center rounded-2xl bg-[#f1e7d4] text-[#2f8f83]"><Icon size={22} /></span><h3 className="mt-4 font-display text-lg font-semibold text-[#222b4b]">{title}</h3><p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-[#77736c]">{text}</p></div></div>;
}

function ErrorState({ onRetry, text = 'The learning layer is taking a quiet moment.' }: { onRetry?: () => void; text?: string }) {
  return <div className="m-5 flex items-center gap-3 rounded-2xl border border-[#e4b7a8] bg-[#fff1ec] p-4 text-sm text-[#873f31]"><CircleAlert size={18} /><span className="flex-1">{text}</span>{onRetry && <button onClick={onRetry} className="inline-flex items-center gap-2 rounded-lg bg-[#873f31] px-3 py-2 text-xs font-semibold text-white" data-testid="button-retry"><RefreshCw size={13} />Retry</button>}</div>;
}

function Home() {
  const curriculum = useListCurriculum();
  const health = useHealthCheck();
  const chapters = curriculum.data ?? [];
  const languages = ['Santali', 'Hindi input', 'English input'];
  return <div className="pb-16">
    <PageHeader eyebrow="SIH 2026 prototype / public education service" title={<>Welcome to <span className="text-[#2b6cb0]">VernacularAI.</span></>} description="Curriculum-grounded multilingual learning assistance for primary education. Support teachers and children with clear explanations in familiar languages." action={<span className="inline-flex items-center gap-2 rounded-md border border-[#c8d5e2] bg-white px-3 py-2 text-xs font-semibold text-[#526173]"><i className="size-2 rounded-full bg-[#2f8f83]" /> Jharkhand pilot</span>} />
    <div className="mx-auto max-w-[1200px] space-y-6 px-5 sm:px-8">
      <section aria-labelledby="quick-actions">
        <div className="mb-3 flex items-center justify-between"><h2 id="quick-actions" className="text-lg font-bold text-[#183b63]">Choose a workspace</h2><span className="text-xs text-[#667085]">Start with the primary teaching flow</span></div>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          <HomeActionCard href="/teacher" icon={GraduationCap} title="Teacher Assistant" text="Start a multilingual teaching session" primary />
          <HomeActionCard href="/student" icon={Lightbulb} title="Student Learning" text="Ask questions in a familiar language" />
          <HomeActionCard href="/curriculum" icon={Library} title="Curriculum" text="Explore indexed learning content" />
          <HomeActionCard href="/dashboard" icon={Gauge} title="System Status" text="Check service and provider availability" />
        </div>
      </section>
      <div className="grid gap-6 lg:grid-cols-[1.2fr_.8fr]">
        <SectionCard className="p-5 sm:p-6">
          <div className="flex items-center justify-between gap-4"><div><Eyebrow>Primary demo</Eyebrow><h2 className="mt-2 text-xl font-bold text-[#183b63]">Grade 3 Environmental Studies</h2></div><span className="rounded-full bg-[#e8f4f1] px-3 py-1.5 text-xs font-semibold text-[#28675e]">Curriculum grounded</span></div>
          <p className="mt-5 max-w-2xl text-sm leading-6 text-[#526173]">Ask why plants need sunlight and receive a simple explanation, a familiar example, key points, a practice quiz, and source evidence.</p>
          <div className="mt-5 flex flex-wrap gap-2 text-xs"><span className="rounded-md bg-[#f2f5f8] px-3 py-2 text-[#526173]">Class 3</span><span className="rounded-md bg-[#f2f5f8] px-3 py-2 text-[#526173]">EVS</span><span className="rounded-md bg-[#f2f5f8] px-3 py-2 text-[#526173]">Santali bridge</span></div>
          <Link href="/teacher" className="mt-6 inline-flex items-center gap-2 rounded-md bg-[#183b63] px-4 py-3 text-sm font-bold text-white hover:bg-[#245687]" data-testid="link-home-primary">Open Teacher Assistant <ArrowRight size={16} /></Link>
        </SectionCard>
        <SectionCard className="p-5 sm:p-6"><div className="flex items-center justify-between"><div><Eyebrow>Service overview</Eyebrow><h2 className="mt-2 text-xl font-bold text-[#183b63]">At a glance</h2></div><span className={cn('rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-[.08em]', health.isError ? 'bg-[#fff1ec] text-[#a14b38]' : 'bg-[#e8f4f1] text-[#28675e]')}>{health.isError ? 'Needs attention' : 'Online'}</span></div><div className="mt-5 space-y-4"><HomeStat label="Indexed chapters" value={curriculum.isLoading ? 'Checking…' : String(chapters.length)} /><HomeStat label="Learning languages" value={String(languages.length)} /><HomeStat label="Server mode" value="Local / Demo" /></div><Link href="/dashboard" className="mt-6 inline-flex items-center gap-2 text-sm font-bold text-[#2b6cb0] hover:text-[#183b63]" data-testid="link-home-status">View service details <ArrowRight size={15} /></Link></SectionCard>
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        <SectionCard className="p-5 sm:p-6"><Eyebrow>Recent learning sessions</Eyebrow><h2 className="mt-2 text-xl font-bold text-[#183b63]">Continue where you left off</h2><p className="mt-3 text-sm leading-6 text-[#667085]">Your latest local session is available in Student Learning and the system trace after you submit a question.</p><Link href="/student" className="mt-5 inline-flex items-center gap-2 rounded-md border border-[#c8d5e2] px-3.5 py-2.5 text-sm font-semibold text-[#183b63] hover:bg-[#f2f5f8]">Open Student Learning <ArrowRight size={15} /></Link></SectionCard>
        <SectionCard className="p-5 sm:p-6"><Eyebrow>Supported languages</Eyebrow><h2 className="mt-2 text-xl font-bold text-[#183b63]">Language-first learning</h2><div className="mt-4 flex flex-wrap gap-2">{languages.map((language) => <span key={language} className="rounded-md border border-[#d8e0ea] bg-[#f7f9fb] px-3 py-2 text-xs font-semibold text-[#526173]">{language}</span>)}</div><p className="mt-4 text-xs leading-5 text-[#667085]">Santali is available through the offline bridge in this prototype. Additional mother tongues can be configured behind the same provider boundary.</p></SectionCard>
      </div>
    </div>
  </div>;
}

function HomeActionCard({ href, icon: Icon, title, text, primary = false }: { href: string; icon: IconType; title: string; text: string; primary?: boolean }) {
  return <Link href={href} className={cn('group rounded-md border p-5 transition-colors', primary ? 'border-[#183b63] bg-[#183b63] text-white hover:bg-[#245687]' : 'border-[#d8e0ea] bg-white text-[#183b63] hover:border-[#2b6cb0] hover:bg-[#f7f9fb]')}><span className={cn('grid size-10 place-items-center rounded-md', primary ? 'bg-[#f7b955] text-[#183b63]' : 'bg-[#e8f0f8] text-[#2b6cb0]')}><Icon size={20} /></span><h3 className="mt-5 text-sm font-bold">{title}</h3><p className={cn('mt-2 text-xs leading-5', primary ? 'text-[#dce8f3]' : 'text-[#667085]')}>{text}</p><span className={cn('mt-5 inline-flex items-center gap-1 text-xs font-bold', primary ? 'text-[#f7d88f]' : 'text-[#2b6cb0]')}>Open <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" /></span></Link>;
}

function HomeStat({ label, value }: { label: string; value: string }) {
  return <div className="flex items-center justify-between border-b border-[#edf0f4] pb-3 text-sm last:border-0 last:pb-0"><span className="text-[#667085]">{label}</span><span className="font-bold text-[#183b63]">{value}</span></div>;
}

function Trace({ label, value, done = false }: { label: string; value: string; done?: boolean }) {
  return <div className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/[.045] px-3 py-2.5"><span className={cn('grid size-6 place-items-center rounded-full', done ? 'bg-[#6dc4a6] text-[#18352e]' : 'bg-white/10 text-[#aeb8d0]')}>{done ? <Check size={13} strokeWidth={3} /> : <span className="size-1.5 rounded-full bg-current" />}</span><span className="flex-1 text-[12px] text-[#dedecf]">{label}</span><span className="font-mono text-[9px] text-[#aeb8d0]">{value}</span></div>;
}

function Stat({ value, label }: { value: string; label: string }) {
  return <div className="border-l border-[#d9d0c1] px-5 first:border-0 first:pl-0 sm:px-8"><div className="font-display text-3xl font-semibold tracking-[-.05em] text-[#222b4b]">{value}</div><div className="mt-1 font-mono text-[9px] uppercase tracking-[.15em] text-[#858079]">{label}</div></div>;
}

function Feature({ index, icon: Icon, title, text }: { index: string; icon: IconType; title: string; text: string }) {
  return <div className="rounded-2xl border border-[#ded6c7] bg-[#fffaf0] p-5 transition-transform hover:-translate-y-1"><div className="flex items-center justify-between text-[#2f8f83]"><Icon size={20} /><span className="font-mono text-[10px] text-[#aaa093]">{index}</span></div><h3 className="mt-8 text-sm font-bold text-[#222b4b]">{title}</h3><p className="mt-2 text-xs leading-5 text-[#77736c]">{text}</p></div>;
}

function Teacher() {
  const curriculum = useListCurriculum();
  const generate = useGenerateLesson();
  const chapters = curriculum.data ?? [];
  const [grade, setGrade] = useState('3');
  const [subject, setSubject] = useState<LearningQuestionInputSubject>('evs');
  const [targetLanguage, setTargetLanguage] = useState<LearningQuestionInputTargetLanguage>('sat');
  const [chapterId, setChapterId] = useState('plants-sunlight');
  const [content, setContent] = useState('Why do plants need sunlight?');
  const [pack, setPack] = useState<LessonPack | null>(null);
  const selected = chapters.find((chapter) => chapter.id === chapterId);
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!content.trim() || generate.isPending) return;
    generate.mutate({ data: { content: content.trim(), sourceLanguage: 'hi', targetLanguage, grade: Number(grade), subject, chapterId: chapterId || null } }, { onSuccess: (result) => { setPack(result); sessionStorage.setItem('vernacular-last-pack', JSON.stringify(result)); } });
  };
  return <div className="pb-16"><PageHeader eyebrow="Teacher Assistant / primary teaching screen" title={<>Curriculum-grounded <span className="text-[#2b6cb0]">teaching support.</span></>} description="Enter or speak a lesson question. VernacularAI prepares a clear local-language bridge, age-appropriate explanation, practice, and source evidence." action={<Link href="/student" className="inline-flex items-center gap-2 text-sm font-bold text-[#2b6cb0] hover:text-[#183b63]" data-testid="link-switch-student">Switch to Student Learning <ArrowRight size={15} /></Link>} /><div className="mx-auto grid max-w-[1200px] gap-6 px-5 sm:px-8 xl:grid-cols-[.7fr_1.3fr]">
      <SectionCard className="h-fit overflow-hidden"><div className="border-b border-[#d8e0ea] bg-[#e8f0f8] px-6 py-5"><div className="flex items-center gap-3"><span className="grid size-9 place-items-center rounded-md bg-[#183b63] text-[#f7b955]"><Settings2 size={17} /></span><div><h2 className="text-sm font-bold text-[#183b63]">Set the learning context</h2><p className="mt-0.5 text-xs text-[#526173]">The selected chapter keeps answers relevant.</p></div></div></div><form onSubmit={submit} className="space-y-5 p-6"><div className="grid grid-cols-2 gap-3"><FieldLabel label="Grade"><div className="relative"><select value={grade} onChange={(event) => setGrade(event.target.value)} className="field appearance-none pr-9" data-testid="select-teacher-grade">{[1, 2, 3, 4, 5].map((value) => <option key={value} value={value}>Class {value}</option>)}</select><ChevronDown className="pointer-events-none absolute right-3 top-3.5 text-[#667085]" size={15} /></div></FieldLabel><FieldLabel label="Subject"><select value={subject} onChange={(event) => setSubject(event.target.value as LearningQuestionInputSubject)} className="field" data-testid="select-teacher-subject"><option value="evs">Environmental Studies</option><option value="mathematics">Mathematics</option></select></FieldLabel></div><FieldLabel label="Target language"><select value={targetLanguage} onChange={() => setTargetLanguage('sat')} className="field" data-testid="select-teacher-language"><option value="sat">Santali · available in demo mode</option></select></FieldLabel><FieldLabel label="Curriculum chapter"><div className="relative"><select value={chapterId} onChange={(event) => setChapterId(event.target.value)} className="field appearance-none pr-9" data-testid="select-teacher-chapter"><option value="">Choose an indexed chapter</option>{chapters.map((chapter) => <option key={chapter.id} value={chapter.id}>Class {chapter.grade} · {chapter.chapter}</option>)}</select><ChevronDown className="pointer-events-none absolute right-3 top-3.5 text-[#667085]" size={15} /></div></FieldLabel>{selected && <div className="rounded-md border border-[#afd5c9] bg-[#e8f4f1] p-3 text-xs leading-5 text-[#28675e]"><div className="flex items-center gap-2 font-bold"><CircleCheck size={14} /> Curriculum grounded</div><p className="mt-1 line-clamp-2 text-[#4c7e76]">{selected.excerpt}</p></div>}<FieldLabel label="Teacher's input (Hindi or English)"><textarea value={content} onChange={(event) => setContent(event.target.value)} className="field min-h-[150px] resize-y leading-6" placeholder="Why do plants need sunlight?" maxLength={2000} data-testid="textarea-lesson-context" /><div className="mt-1 text-right font-mono text-[9px] text-[#667085]">{content.length}/2000</div></FieldLabel><VoiceCaptureButton onText={setContent} /><button type="submit" disabled={generate.isPending || !content.trim()} className="flex w-full items-center justify-center gap-2 rounded-md bg-[#183b63] px-4 py-3.5 text-sm font-bold text-white hover:bg-[#245687] disabled:cursor-not-allowed disabled:opacity-60" data-testid="button-generate-lesson">{generate.isPending ? <><span className="size-3 animate-spin rounded-full border-2 border-[#f7b955] border-t-transparent" />Preparing response…</> : <><Sparkles size={16} />Process lesson</>}</button>{generate.isError && <p className="text-xs text-[#a14b38]" data-testid="status-lesson-error">The lesson could not be prepared. Check the input and try again.</p>}</form></SectionCard>
    <div className="min-h-[500px]">{generate.isPending ? <LessonSkeleton /> : pack ? <LessonPackView pack={pack} /> : <SectionCard className="h-full"><EmptyState icon={ClipboardList} title="Your lesson pack will land here" text="Choose a chapter or paste your lesson context, then let the learning layer prepare the next class." /></SectionCard>}</div>
  </div></div>;
}

function FieldLabel({ label, children }: { label: string; children: ReactNode }) {
  return <label className="block"><span className="mb-2 block font-mono text-[10px] font-bold uppercase tracking-[.16em] text-[#77736c]">{label}</span>{children}</label>;
}

function LessonSkeleton() {
  return <SectionCard className="space-y-5 p-6"><div className="h-6 w-2/3 animate-pulse rounded bg-[#e9e0d1]" /><div className="h-4 w-1/3 animate-pulse rounded bg-[#eee6d9]" /><div className="h-28 animate-pulse rounded-2xl bg-[#f1e7d4]" /><div className="grid gap-4 sm:grid-cols-2"><div className="h-32 animate-pulse rounded-2xl bg-[#f1e7d4]" /><div className="h-32 animate-pulse rounded-2xl bg-[#f1e7d4]" /></div><p className="font-mono text-[10px] uppercase tracking-[.14em] text-[#8d877e]">Grounding the lesson in your curriculum…</p></SectionCard>;
}

function LessonPackView({ pack }: { pack: LessonPack }) {
  return <div className="space-y-4 animate-rise-in"><SectionCard className="overflow-hidden"><div className="bg-[#222b4b] p-6 text-[#fffaf0] sm:p-7"><div className="flex items-start justify-between gap-4"><div><Eyebrow tone="dark">Generated lesson pack</Eyebrow><h2 className="mt-3 font-display text-3xl font-semibold leading-tight tracking-[-.05em]">{pack.title}</h2></div><span className="rounded-full border border-[#6dc4a6]/30 bg-[#6dc4a6]/10 px-3 py-1.5 font-mono text-[9px] text-[#8ee0bc]">{pack.latency.totalMs} ms</span></div><p className="mt-6 max-w-2xl font-display text-lg leading-8 text-[#f2dec0]">{pack.translatedLesson}</p></div><div className="grid divide-y divide-[#e5ddcf] sm:grid-cols-2 sm:divide-x sm:divide-y-0"><LessonBlock icon={Lightbulb} title="Explain simply" text={pack.explanation} /><LessonBlock icon={Network} title="A local example" text={pack.example} /></div></SectionCard><div className="grid gap-4 sm:grid-cols-2"><SectionCard className="p-5"><div className="flex items-center gap-2 text-[#2f8f83]"><ListChecks size={17} /><h3 className="text-sm font-bold text-[#222b4b]">Worksheet prompts</h3></div><ol className="mt-4 space-y-3">{pack.worksheet.map((item, index) => <li key={`${item}-${index}`} className="flex gap-3 text-sm leading-6 text-[#62656c]"><span className="font-mono text-xs text-[#bc7c1b]">0{index + 1}</span>{item}</li>)}</ol></SectionCard><SectionCard className="p-5"><div className="flex items-center gap-2 text-[#2f8f83]"><BookOpenText size={17} /><h3 className="text-sm font-bold text-[#222b4b]">Flashcards</h3></div><div className="mt-4 space-y-2">{pack.flashcards.map((card, index) => <div key={`${card.front}-${index}`} className="rounded-xl bg-[#f1e7d4] p-3"><div className="text-xs font-bold text-[#222b4b]">{card.front}</div><div className="mt-1 text-xs leading-5 text-[#77736c]">{card.back}</div></div>)}</div></SectionCard></div><QuizBlock quiz={pack.quiz} /><Sources sources={pack.sources} /></div>;
}

function LessonBlock({ icon: Icon, title, text }: { icon: IconType; title: string; text: string }) {
  return <div className="p-5"><div className="flex items-center gap-2 text-[#bc7c1b]"><Icon size={16} /><span className="font-mono text-[10px] font-bold uppercase tracking-[.13em]">{title}</span></div><p className="mt-3 text-sm leading-6 text-[#62656c]">{text}</p></div>;
}

function QuizBlock({ quiz }: { quiz: Array<{ question: string; options: string[]; answer: string }> }) {
  return <SectionCard className="p-5"><div className="flex items-center gap-2 text-[#2f8f83]"><ListChecks size={17} /><h3 className="text-sm font-bold text-[#222b4b]">Ready-to-use quiz</h3><span className="ml-auto font-mono text-[9px] uppercase tracking-[.12em] text-[#9a9287]">{quiz.length} prompts</span></div><div className="mt-4 grid gap-3 md:grid-cols-2">{quiz.map((item, index) => <div key={`${item.question}-${index}`} className="rounded-xl border border-[#ded6c7] p-4"><div className="font-mono text-[9px] uppercase tracking-[.12em] text-[#bc7c1b]">question 0{index + 1}</div><p className="mt-2 text-sm font-semibold leading-6 text-[#222b4b]">{item.question}</p><div className="mt-3 flex flex-wrap gap-1.5">{item.options.map((option) => <span key={option} className="rounded-md bg-[#f1e7d4] px-2 py-1 text-[10px] text-[#77736c]">{option}</span>)}</div><p className="mt-3 text-xs text-[#2f8f83]">Answer: <span className="font-semibold">{item.answer}</span></p></div>)}</div></SectionCard>;
}

function Student() {
  const curriculum = useListCurriculum();
  const ask = useAskLearningQuestion();
  const feedback = useSubmitFeedback();
  const chapters = curriculum.data ?? [];
  const [question, setQuestion] = useState('Why do plants need sunlight?');
  const [grade, setGrade] = useState('3');
  const [chapterId, setChapterId] = useState('plants-sunlight');
  const [response, setResponse] = useState<LearningResponse | null>(() => {
    try { const saved = sessionStorage.getItem('vernacular-last-response'); return saved ? JSON.parse(saved) : null; } catch { return null; }
  });
  const [feedbackSent, setFeedbackSent] = useState(false);
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!question.trim() || ask.isPending) return;
     ask.mutate({ data: { question: question.trim(), sourceLanguage: 'en', targetLanguage: 'sat', grade: Number(grade), subject: 'evs', chapterId: chapterId || null } }, { onSuccess: (result) => { setResponse(result); setFeedbackSent(false); sessionStorage.setItem('vernacular-last-response', JSON.stringify(result)); } });
  };
  const giveFeedback = (helpful: boolean) => {
    if (!response || feedbackSent) return;
    feedback.mutate({ data: { helpful, question: response.question, targetLanguage: 'sat' } }, { onSuccess: () => setFeedbackSent(true) });
  };
  return <div className="pb-16"><PageHeader eyebrow="Student Learning / ask and learn" title={<>What would you like to <span className="text-[#2b6cb0]">learn?</span></>} description="Ask in a familiar language. Type your question or use voice input, then read a clear answer with an example and practice." action={<div className="flex items-center gap-2 rounded-md border border-[#d8e0ea] bg-white px-3 py-2 text-xs font-semibold text-[#526173]"><Mic2 size={15} className="text-[#2f8f83]" /> Voice when available</div>} /><div className="mx-auto grid max-w-[1200px] gap-6 px-5 sm:px-8 xl:grid-cols-[.62fr_1.38fr]">
      <SectionCard className="h-fit overflow-hidden"><div className="bg-[#183b63] p-6 text-white"><div className="grid size-11 place-items-center rounded-md bg-[#f7b955] text-[#183b63]"><MessageCircleQuestion size={22} /></div><h2 className="mt-5 text-2xl font-bold tracking-[-.03em]">Ask a question</h2><p className="mt-2 text-sm leading-6 text-[#dce8f3]">Type it the way you would ask your teacher. Simple questions are welcome.</p></div><form onSubmit={submit} className="space-y-5 p-6"><FieldLabel label="Your question"><textarea value={question} onChange={(event) => setQuestion(event.target.value)} className="field min-h-[138px] resize-none text-lg leading-8" placeholder="Why do plants need sunlight?" maxLength={1000} data-testid="textarea-student-question" /></FieldLabel><div><span className="mb-2 block text-xs font-semibold text-[#526173]">Try an example</span><div className="flex flex-wrap gap-2">{['Why do plants need sunlight?', 'Why do we need water?', 'What are animals?'].map((prompt) => <button key={prompt} type="button" onClick={() => { setQuestion(prompt); setChapterId(prompt.includes('plants') ? 'plants-sunlight' : ''); }} className="rounded-md border border-[#d8e0ea] bg-white px-2.5 py-2 text-left text-[11px] font-semibold text-[#526173] hover:border-[#2b6cb0] hover:text-[#183b63]">{prompt}</button>)}</div></div><VoiceCaptureButton onText={setQuestion} /><div className="grid grid-cols-2 gap-3"><FieldLabel label="Class"><select value={grade} onChange={(event) => setGrade(event.target.value)} className="field" data-testid="select-student-grade">{[1, 2, 3, 4, 5].map((value) => <option key={value} value={value}>{value}</option>)}</select></FieldLabel><FieldLabel label="Chapter"><select value={chapterId} onChange={(event) => setChapterId(event.target.value)} className="field truncate" data-testid="select-student-chapter"><option value="">Any chapter</option>{chapters.map((chapter) => <option key={chapter.id} value={chapter.id}>{chapter.chapter}</option>)}</select></FieldLabel></div><button type="submit" disabled={!question.trim() || ask.isPending} className="flex w-full items-center justify-center gap-2 rounded-md bg-[#183b63] px-4 py-3.5 text-sm font-bold text-white hover:bg-[#245687] disabled:cursor-not-allowed disabled:opacity-60" data-testid="button-ask-question">{ask.isPending ? <><span className="size-3 animate-spin rounded-full border-2 border-[#f7b955] border-t-transparent" />Finding an answer…</> : <><Send size={16} />Ask VernacularAI</>}</button>{ask.isError && <p className="text-xs text-[#a14b38]" data-testid="status-student-error">We could not reach the learning service. Please try again.</p>}</form></SectionCard>
    <div className="min-h-[500px]">{ask.isPending ? <AnswerSkeleton /> : response ? <AnswerView response={response} onFeedback={giveFeedback} feedbackSent={feedbackSent} /> : <SectionCard className="h-full"><EmptyState icon={Lightbulb} title="A clear answer is waiting" text="Your response will include a simple explanation, a familiar example, a tiny quiz, and voice status." /></SectionCard>}</div>
  </div></div>;
}

function AnswerSkeleton() {
  return <SectionCard className="space-y-5 p-6"><div className="h-5 w-1/3 animate-pulse rounded bg-[#e9e0d1]" /><div className="h-24 animate-pulse rounded-2xl bg-[#edf8f3]" /><div className="h-16 animate-pulse rounded-2xl bg-[#f1e7d4]" /><div className="h-40 animate-pulse rounded-2xl bg-[#f1e7d4]" /><p className="font-mono text-[10px] uppercase tracking-[.14em] text-[#8d877e]">Finding the kindest explanation…</p></SectionCard>;
}

type BrowserRecognition = {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  start: () => void;
  onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onend: (() => void) | null;
  onerror: (() => void) | null;
};

function VoiceCaptureButton({ onText }: { onText: (text: string) => void }) {
  const [listening, setListening] = useState(false);
  const [message, setMessage] = useState('Use your voice');
  const supported = typeof window !== 'undefined' && Boolean((window as Window & { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown }).SpeechRecognition || (window as Window & { webkitSpeechRecognition?: unknown }).webkitSpeechRecognition);
  const start = () => {
    const browserWindow = window as Window & { SpeechRecognition?: new () => BrowserRecognition; webkitSpeechRecognition?: new () => BrowserRecognition };
    const Recognition = browserWindow.SpeechRecognition || browserWindow.webkitSpeechRecognition;
    if (!Recognition) {
      setMessage('Voice input is unavailable; type instead.');
      return;
    }
    const recognition = new Recognition();
    recognition.lang = 'hi-IN';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.onresult = (event) => {
      const transcript = event.results[0]?.[0]?.transcript;
      if (transcript) onText(transcript);
      setMessage('Voice captured');
    };
    recognition.onend = () => setListening(false);
    recognition.onerror = () => {
      setListening(false);
      setMessage('Voice input unavailable; type instead.');
    };
    setListening(true);
    setMessage('Listening…');
    recognition.start();
  };
  return <div className="flex items-center gap-3 rounded-xl border border-[#ded6c7] bg-[#f8f3e7] p-3"><button type="button" onClick={start} disabled={!supported || listening} className="inline-flex items-center gap-2 rounded-lg border border-[#cfc5b2] bg-[#fffaf0] px-3 py-2 text-xs font-bold text-[#222b4b] hover:border-[#2f8f83] disabled:cursor-not-allowed disabled:opacity-50" data-testid="button-student-voice"><Mic2 size={14} />{listening ? 'Listening…' : 'Speak question'}</button><span className="text-[11px] text-[#77736c]">{supported ? message : 'Voice input unavailable; type instead.'}</span></div>;
}

function AnswerView({ response, onFeedback, feedbackSent }: { response: LearningResponse; onFeedback: (helpful: boolean) => void; feedbackSent: boolean }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const canSpeak = typeof window !== 'undefined' && 'speechSynthesis' in window;
  const play = () => {
    if (!canSpeak) return;
    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
      return;
    }
    // The current prototype does not include a validated Santali TTS provider.
    // Speak the Hindi explanation instead of reading Ol Chiki text with a Hindi voice.
    const utterance = new SpeechSynthesisUtterance(response.answer);
    utterance.lang = 'hi-IN';
    utterance.onend = () => setIsPlaying(false);
    utterance.onerror = () => setIsPlaying(false);
    window.speechSynthesis.speak(utterance);
    setIsPlaying(true);
  };
  return <div className="space-y-4 animate-rise-in"><SectionCard className="overflow-hidden"><div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#e5ddcf] bg-[#f1e7d4] px-5 py-4"><div className="flex items-center gap-2 text-[#222b4b]"><span className="grid size-7 place-items-center rounded-lg bg-[#2f8f83] text-white"><Sparkles size={14} /></span><span className="font-mono text-[10px] font-bold uppercase tracking-[.16em]">Your answer</span></div><div className="flex items-center gap-2 font-mono text-[9px] text-[#77736c]"><Timer size={13} /> {response.latency.totalMs} ms · {response.detectedLanguage.toUpperCase()}</div></div><div className="p-5 sm:p-7"><p className="font-mono text-[10px] uppercase tracking-[.14em] text-[#9a9287]">You asked</p><p className="mt-2 font-display text-xl font-semibold text-[#222b4b]">{response.question}</p><div className="mt-5 rounded-2xl border-l-4 border-[#2f8f83] bg-[#edf8f3] p-5"><p className="font-mono text-[9px] uppercase tracking-[.14em] text-[#4c7e76]">Target-language preview · phrasebook demo</p><p className="mt-2 text-[17px] leading-8 text-[#285950]">{response.targetAnswer || response.answer}</p><p className="mt-3 text-[11px] leading-5 text-[#4c7e76]">Prototype output only. Santali translation has not yet been validated by native speakers.</p></div><div className="mt-5 grid gap-4 sm:grid-cols-2"><div className="rounded-2xl border border-[#ded6c7] p-4"><div className="flex items-center gap-2 text-[#bc7c1b]"><BookOpenText size={15} /><span className="text-xs font-bold">An example</span></div><p className="mt-3 text-sm leading-6 text-[#62656c]">{response.targetExample || response.example}</p></div><div className="rounded-2xl border border-[#ded6c7] p-4"><div className="flex items-center gap-2 text-[#bc7c1b]"><ListChecks size={15} /><span className="text-xs font-bold">Remember these</span></div><ul className="mt-3 space-y-2">{response.keyPoints.map((point, index) => <li key={`${point}-${index}`} className="flex gap-2 text-sm leading-5 text-[#62656c]"><Check size={14} className="mt-0.5 shrink-0 text-[#2f8f83]" />{point}</li>)}</ul></div></div></div></SectionCard><SectionCard className="p-5"><div className="flex flex-wrap items-center justify-between gap-3"><div className="flex items-center gap-2 text-[#222b4b]"><Volume2 size={17} className="text-[#2f8f83]" /><h3 className="text-sm font-bold">Listen to the Hindi explanation</h3></div><span className={cn('rounded-full px-2.5 py-1 font-mono text-[9px] uppercase tracking-[.12em]', canSpeak ? 'bg-[#edf8f3] text-[#28675e]' : 'bg-[#f1e7d4] text-[#77736c]')}>{canSpeak ? 'Hindi device voice' : 'voice unavailable'}</span></div><div className="mt-3 flex items-center gap-3 rounded-xl bg-[#f8f3e7] p-3 text-xs text-[#77736c]"><button onClick={play} disabled={!canSpeak} className="grid size-9 place-items-center rounded-full bg-[#222b4b] text-[#fffaf0] disabled:opacity-40" aria-label={isPlaying ? 'Pause answer voice' : 'Play answer voice'} data-testid="button-play-voice">{isPlaying ? <Volume2 size={14} /> : <Play size={14} fill="currentColor" />}</button><span>{isPlaying ? 'Playing the Hindi explanation using your device voice.' : canSpeak ? 'Your browser can read the Hindi explanation aloud. Santali TTS is not connected yet.' : response.voice.message}</span></div></SectionCard><SectionCard className="p-5"><div className="flex items-center justify-between gap-3"><div><h3 className="text-sm font-bold text-[#222b4b]">Quick check</h3><p className="mt-1 text-xs text-[#77736c]">Can you explain it back?</p></div><span className="font-mono text-[9px] uppercase tracking-[.14em] text-[#9a9287]">{response.quiz.length} questions</span></div><div className="mt-4 space-y-3">{response.quiz.map((quiz, index) => <details key={`${quiz.question}-${index}`} className="group rounded-xl border border-[#ded6c7] p-3"><summary className="cursor-pointer list-none text-sm font-semibold text-[#222b4b]"><span className="mr-2 font-mono text-[10px] text-[#bc7c1b]">0{index + 1}</span>{quiz.question}<ChevronDown size={15} className="float-right mt-0.5 transition-transform group-open:rotate-180" /></summary><div className="mt-3 border-t border-[#e5ddcf] pt-3 text-xs leading-5 text-[#62656c]">उत्तर: <span className="font-semibold text-[#2f8f83]">{quiz.answer}</span><div className="mt-2 flex flex-wrap gap-2">{quiz.options.map((option) => <span key={option} className="rounded-md bg-[#f1e7d4] px-2 py-1">{option}</span>)}</div></div></details>)}</div></SectionCard><div className="flex flex-wrap items-center justify-between gap-3 px-1"><div className="flex items-center gap-2 text-xs text-[#77736c]"><span>Was this helpful?</span><button onClick={() => onFeedback(true)} disabled={feedbackSent} className="rounded-lg p-2 hover:bg-[#edf8f3] disabled:opacity-50" data-testid="button-feedback-helpful"><ThumbsUp size={15} /></button><button onClick={() => onFeedback(false)} disabled={feedbackSent} className="rounded-lg p-2 hover:bg-[#fff1ec] disabled:opacity-50" data-testid="button-feedback-not-helpful"><ThumbsDown size={15} /></button>{feedbackSent && <span className="text-[#2f8f83]">Thank you.</span>}</div><Sources sources={response.sources} /></div></div>;
}

function Sources({ sources }: { sources: Array<{ id: string; text: string; score: number; metadata: { label: string; page: string } }> }) {
  return <div className="rounded-[20px] border border-[#ded6c7] bg-[#fffaf0] p-5"><div className="flex items-center gap-2 text-[#222b4b]"><Database size={16} className="text-[#2f8f83]" /><h3 className="text-sm font-bold">Grounded in</h3><span className="ml-auto font-mono text-[9px] uppercase tracking-[.14em] text-[#9a9287]">{sources.length} chunks</span></div>{sources.length ? <div className="mt-4 grid gap-2">{sources.slice(0, 3).map((source) => <div key={source.id} className="flex gap-3 rounded-xl bg-[#f1e7d4] p-3"><span className="mt-0.5 font-mono text-[10px] text-[#bc7c1b]">{Math.round(source.score * 100)}% match</span><div className="min-w-0"><p className="line-clamp-2 text-xs leading-5 text-[#62656c]">{source.text}</p><p className="mt-1 font-mono text-[9px] uppercase tracking-[.1em] text-[#9a9287]">{source.metadata.label} · p.{source.metadata.page}</p></div></div>)}</div> : <p className="mt-3 text-xs text-[#77736c]">No source chunks returned.</p>}</div>;
}

function Curriculum() {
  const curriculum = useListCurriculum();
  const chapters = curriculum.data ?? [];
  const [selectedId, setSelectedId] = useState('');
  const activeId = selectedId || chapters[0]?.id || '';
  const detailQuery = useGetCurriculumChapter(activeId, { query: { enabled: Boolean(activeId), queryKey: getGetCurriculumChapterQueryKey(activeId) } });
  const detail = detailQuery.data as CurriculumChapterDetail | undefined;
  const [filter, setFilter] = useState('');
  const [gradeFilter, setGradeFilter] = useState('all');
  const [subjectFilter, setSubjectFilter] = useState('all');
  const [languageFilter, setLanguageFilter] = useState('all');
  const filtered = useMemo(() => chapters.filter((chapter) => {
    const matchesText = `${chapter.chapter} ${chapter.subject} ${chapter.source}`.toLowerCase().includes(filter.toLowerCase());
    const matchesGrade = gradeFilter === 'all' || String(chapter.grade) === gradeFilter;
    const matchesSubject = subjectFilter === 'all' || chapter.subject === subjectFilter;
    const matchesLanguage = languageFilter === 'all' || languageFilter === 'sat';
    return matchesText && matchesGrade && matchesSubject && matchesLanguage;
  }), [chapters, filter, gradeFilter, subjectFilter, languageFilter]);
  return <div className="pb-16"><PageHeader eyebrow="Curriculum / indexed library" title={<>Explore <span className="text-[#2b6cb0]">curriculum evidence.</span></>} description="Browse the reviewed learning content behind each grounded explanation. Filter by grade, subject, chapter, and available learning language." action={<div className="flex items-center gap-2 text-xs font-semibold text-[#526173]"><Layers3 size={15} className="text-[#2b6cb0]" /> {chapters.length || '—'} chapters indexed</div>} />{curriculum.isLoading ? <div className="mx-auto max-w-[1200px] px-5 sm:px-8"><div className="grid gap-4 md:grid-cols-3">{[1, 2, 3].map((item) => <div className="h-32 animate-pulse rounded-md bg-[#e8edf3]" key={item} />)}</div></div> : curriculum.isError ? <div className="mx-auto max-w-[1200px] px-5 sm:px-8"><ErrorState onRetry={() => curriculum.refetch()} /></div> : !chapters.length ? <div className="mx-auto max-w-[1200px] px-5 sm:px-8"><SectionCard><EmptyState icon={Library} title="The library is still being prepared" text="Indexed chapters will appear here when the curriculum service is ready." /></SectionCard></div> : <div className="mx-auto grid max-w-[1200px] gap-5 px-5 sm:px-8 xl:grid-cols-[.8fr_1.2fr]"><SectionCard className="overflow-hidden"><div className="border-b border-[#d8e0ea] p-4"><div className="relative"><Search size={15} className="absolute left-3 top-3.5 text-[#7c8798]" /><input value={filter} onChange={(event) => setFilter(event.target.value)} className="field pl-9" placeholder="Search chapters…" aria-label="Search chapters" data-testid="input-search-curriculum" /></div><div className="mt-3 grid grid-cols-3 gap-2"><select value={gradeFilter} onChange={(event) => setGradeFilter(event.target.value)} className="field text-xs" aria-label="Filter by grade"><option value="all">All grades</option>{[1, 2, 3, 4, 5].map((value) => <option key={value} value={value}>Class {value}</option>)}</select><select value={subjectFilter} onChange={(event) => setSubjectFilter(event.target.value)} className="field text-xs" aria-label="Filter by subject"><option value="all">All subjects</option><option value="evs">EVS</option><option value="mathematics">Mathematics</option></select><select value={languageFilter} onChange={(event) => setLanguageFilter(event.target.value)} className="field text-xs" aria-label="Filter by language"><option value="all">All languages</option><option value="sat">Santali</option></select></div></div><div className="max-h-[600px] overflow-auto p-2">{filtered.length ? filtered.map((chapter) => <ChapterRow key={chapter.id} chapter={chapter} active={chapter.id === activeId} onClick={() => setSelectedId(chapter.id)} />) : <EmptyState icon={Search} title="No chapter found" text="Try a different filter or search term." />}</div></SectionCard><div className="min-w-0">{detailQuery.isLoading ? <SectionCard className="space-y-5 p-6"><div className="h-7 w-2/3 animate-pulse rounded bg-[#e8edf3]" /><div className="h-4 w-1/3 animate-pulse rounded bg-[#edf1f5]" /><div className="h-48 animate-pulse rounded-md bg-[#eef2f6]" /></SectionCard> : detailQuery.isError ? <SectionCard><ErrorState onRetry={() => detailQuery.refetch()} text="This chapter detail could not be opened." /></SectionCard> : detail ? <ChapterDetail detail={detail} /> : <SectionCard><EmptyState icon={FileText} title="Select a chapter" text="Choose a chapter from the library to inspect its source and chunks." /></SectionCard>}</div></div>}</div>;
}

function ChapterRow({ chapter, active, onClick }: { chapter: CurriculumChapter; active: boolean; onClick: () => void }) {
  return <button onClick={onClick} className={cn('w-full rounded-xl p-4 text-left transition-colors', active ? 'bg-[#222b4b] text-[#fffaf0]' : 'hover:bg-[#f1e7d4]')} data-testid={`button-chapter-${chapter.id}`}><div className="flex items-start gap-3"><span className={cn('mt-0.5 grid size-8 shrink-0 place-items-center rounded-lg', active ? 'bg-[#f7b955] text-[#222b4b]' : 'bg-[#edf8f3] text-[#2f8f83]')}><BookMarked size={15} /></span><span className="min-w-0 flex-1"><span className="flex items-center justify-between gap-2"><span className="truncate text-sm font-bold">{chapter.chapter}</span><span className={cn('shrink-0 font-mono text-[9px]', active ? 'text-[#d7d8de]' : 'text-[#9a9287]')}>C{chapter.grade}</span></span><span className={cn('mt-1 block truncate text-xs', active ? 'text-[#c9cfdf]' : 'text-[#77736c]')}>{chapter.subject} · {chapter.chunkCount} chunks</span><span className={cn('mt-2 flex items-center gap-1.5 text-[10px]', active ? 'text-[#8ee0bc]' : chapter.indexed ? 'text-[#2f8f83]' : 'text-[#a14b38]')}><i className="size-1.5 rounded-full bg-current" />{chapter.indexed ? 'indexed and ready' : 'awaiting index'}</span></span></div></button>;
}

function ChapterDetail({ detail }: { detail: CurriculumChapterDetail }) {
  return <SectionCard className="overflow-hidden"><div className="bg-[#222b4b] p-6 text-[#fffaf0]"><div className="flex flex-wrap items-center gap-2"><span className="rounded-full bg-[#f7b955] px-2.5 py-1 font-mono text-[9px] font-bold uppercase tracking-[.14em] text-[#222b4b]">Class {detail.grade}</span><span className="rounded-full border border-white/15 px-2.5 py-1 font-mono text-[9px] uppercase tracking-[.14em] text-[#c9cfdf]">{detail.subject}</span><span className="ml-auto flex items-center gap-1.5 font-mono text-[9px] text-[#8ee0bc]"><CircleCheck size={13} /> {detail.chunkCount} indexed chunks</span></div><h2 className="mt-5 font-display text-3xl font-semibold tracking-[-.05em]">{detail.chapter}</h2><p className="mt-2 text-sm text-[#c9cfdf]">{detail.source}</p></div><div className="grid divide-y divide-[#e5ddcf] lg:grid-cols-[1.05fr_.95fr] lg:divide-x lg:divide-y-0"><div className="p-6"><div className="flex items-center gap-2"><FileText size={16} className="text-[#2f8f83]" /><h3 className="text-sm font-bold text-[#222b4b]">Original text</h3></div><p className="mt-4 whitespace-pre-wrap text-sm leading-7 text-[#62656c]">{detail.originalText || detail.excerpt}</p><div className="mt-5 rounded-xl bg-[#f1e7d4] p-3 text-xs leading-5 text-[#77736c]"><span className="font-mono text-[9px] uppercase tracking-[.12em] text-[#bc7c1b]">Excerpt</span><br />{detail.excerpt}</div></div><div className="p-6"><div className="flex items-center justify-between"><div className="flex items-center gap-2"><Network size={16} className="text-[#2f8f83]" /><h3 className="text-sm font-bold text-[#222b4b]">Retrieval chunks</h3></div><span className="font-mono text-[9px] text-[#9a9287]">score / metadata</span></div><div className="mt-4 space-y-3">{detail.chunks.map((chunk, index) => <div key={chunk.id} className="rounded-xl border border-[#ded6c7] p-3"><div className="flex items-center justify-between gap-2"><span className="font-mono text-[9px] uppercase tracking-[.12em] text-[#bc7c1b]">chunk {String(index + 1).padStart(2, '0')}</span><span className="font-mono text-[10px] font-bold text-[#2f8f83]">{Math.round(chunk.score * 100)}%</span></div><p className="mt-2 text-xs leading-5 text-[#62656c]">{chunk.text}</p><div className="mt-2 flex flex-wrap gap-1.5">{[chunk.metadata.publisher, `p.${chunk.metadata.page}`, chunk.metadata.label].map((meta) => <span key={meta} className="rounded bg-[#f1e7d4] px-1.5 py-1 font-mono text-[8px] uppercase tracking-[.08em] text-[#8b8378]">{meta}</span>)}</div></div>)}</div></div></div></SectionCard>;
}

function Dashboard() {
  const health = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey() } });
  const systemStatus = useGetSystemStatus();
  const curriculum = useListCurriculum();
  const [lastResponse, setLastResponse] = useState<LearningResponse | null>(() => {
    try { const saved = sessionStorage.getItem('vernacular-last-response'); return saved ? JSON.parse(saved) : null; } catch { return null; }
  });
  const chapterCount = curriculum.data?.length ?? 0;
  const indexedCount = curriculum.data?.filter((chapter) => chapter.indexed).length ?? 0;
  const statuses = lastResponse?.status;
  const steps = [
    ['Language detection', statuses?.languageDetection ?? (health.data ? 'ready' : 'pending'), 'hi'],
    ['Translation bridge', statuses?.translation ?? (health.data ? 'ready' : 'pending'), 'hi → sat'],
    ['Curriculum retrieval', statuses?.rag ?? (indexedCount ? 'ready' : 'pending'), `${lastResponse?.sources.length ?? '—'} chunks`],
    ['Pedagogy layer', statuses?.pedagogy ?? (health.data ? 'ready' : 'pending'), 'primary'],
    ['Quiz generation', statuses?.quiz ?? (health.data ? 'ready' : 'pending'), 'practice'],
    ['Voice metadata', statuses?.tts ?? (health.data ? 'ready' : 'pending'), lastResponse?.voice.available ? 'available' : 'standby'],
  ] as const;
  return <div className="pb-16"><PageHeader eyebrow="How VernacularAI knows / system readiness" title={<>Show the work behind <span className="text-[#2f8f83]">the answer.</span></>} description="A judge-facing view of the learning trace: service health, curriculum grounding, provider readiness, and the real timings from your latest run." action={<button onClick={() => { setLastResponse(null); sessionStorage.removeItem('vernacular-last-response'); }} className="inline-flex items-center gap-2 rounded-xl border border-[#d6cdbd] bg-[#fffaf0] px-3.5 py-2.5 text-xs font-bold text-[#222b4b] hover:border-[#2f8f83]" data-testid="button-clear-session"><RefreshCw size={14} />Clear latest run</button>} /><div className="mx-auto max-w-[1200px] space-y-5 px-5 sm:px-8"><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><ReadinessCard icon={ShieldCheck} label="API service" value={health.isLoading ? 'checking' : health.isError ? 'offline' : health.data?.status || 'ready'} tone={health.isError ? 'red' : 'teal'} /><ReadinessCard icon={Library} label="Indexed chapters" value={`${indexedCount} / ${chapterCount || '—'}`} tone="saffron" /><ReadinessCard icon={Timer} label="Latest end-to-end" value={lastResponse ? `${lastResponse.latency.totalMs} ms` : 'no run yet'} tone="navy" /><ReadinessCard icon={BrainCircuit} label="Context mode" value={lastResponse ? 'chapter-grounded' : 'waiting for ask'} tone="teal" /></div><SystemStatusPanel status={systemStatus.data} loading={systemStatus.isLoading} error={systemStatus.isError} /><div className="grid gap-5 xl:grid-cols-[1.15fr_.85fr]"><SectionCard className="overflow-hidden"><div className="flex items-center justify-between border-b border-[#e5ddcf] px-5 py-4"><div><Eyebrow>Pipeline trace</Eyebrow><h2 className="mt-2 font-display text-xl font-semibold tracking-[-.04em] text-[#222b4b]">From question to grounded answer</h2></div><span className={cn('rounded-full px-2.5 py-1 font-mono text-[9px] uppercase tracking-[.13em]', lastResponse ? 'bg-[#edf8f3] text-[#28675e]' : 'bg-[#f1e7d4] text-[#77736c]')}>{lastResponse ? 'latest run' : 'awaiting run'}</span></div><div className="divide-y divide-[#e5ddcf] p-2">{steps.map(([label, status, detail], index) => <PipelineRow key={label} index={index} label={label} status={status} detail={detail} />)}</div>{lastResponse && <div className="m-3 rounded-xl bg-[#f1e7d4] p-3 text-xs text-[#62656c]"><span className="font-mono text-[9px] uppercase tracking-[.12em] text-[#bc7c1b]">Latest prompt</span><p className="mt-1 font-display text-base text-[#222b4b]">{lastResponse.question}</p></div>}</SectionCard><SectionCard className="overflow-hidden"><div className="border-b border-[#e5ddcf] px-5 py-4"><Eyebrow>Latency / milliseconds</Eyebrow><h2 className="mt-2 font-display text-xl font-semibold tracking-[-.04em] text-[#222b4b]">What the learner feels</h2></div>{lastResponse ? <LatencyPanel response={lastResponse} /> : <EmptyState icon={Timer} title="No live trace yet" text="Ask a question in student mode, then return here to inspect the real pipeline timings." />}<Link href="/student" className="mx-5 mb-5 flex items-center justify-between rounded-xl bg-[#222b4b] px-4 py-3 text-xs font-bold text-[#fffaf0] hover:bg-[#2e385e]" data-testid="link-dashboard-student"><span>Run a student question</span><ArrowRight size={15} /></Link></SectionCard></div><SectionCard className="overflow-hidden"><div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#e5ddcf] px-5 py-4"><div><Eyebrow>Retrieval context</Eyebrow><h2 className="mt-2 font-display text-xl font-semibold tracking-[-.04em] text-[#222b4b]">Chunks making the answer possible</h2></div><Link href="/curriculum" className="inline-flex items-center gap-1 text-xs font-bold text-[#2f8f83]" data-testid="link-dashboard-curriculum">Inspect curriculum <ChevronRight size={14} /></Link></div>{lastResponse?.sources.length ? <div className="grid gap-3 p-4 md:grid-cols-3">{lastResponse.sources.slice(0, 3).map((source) => <div key={source.id} className="rounded-xl border border-[#ded6c7] p-4"><div className="flex justify-between font-mono text-[9px] text-[#bc7c1b]"><span>{source.metadata.label}</span><span>{Math.round(source.score * 100)}% match</span></div><p className="mt-3 text-xs leading-5 text-[#62656c]">{source.text}</p><p className="mt-3 font-mono text-[9px] uppercase tracking-[.1em] text-[#9a9287]">{source.metadata.publisher} · p.{source.metadata.page}</p></div>)}</div> : <EmptyState icon={Database} title="Context will appear after a run" text="The retrieved chapter chunks are shown here so every explanation stays accountable." />}</SectionCard></div></div>;
}

function ReadinessCard({ icon: Icon, label, value, tone }: { icon: IconType; label: string; value: string; tone: 'red' | 'teal' | 'saffron' | 'navy' }) {
  return <SectionCard className="p-4"><div className="flex items-center justify-between"><span className={cn('grid size-8 place-items-center rounded-lg', tone === 'red' ? 'bg-[#fff1ec] text-[#a14b38]' : tone === 'teal' ? 'bg-[#edf8f3] text-[#2f8f83]' : tone === 'saffron' ? 'bg-[#fdf2d8] text-[#bc7c1b]' : 'bg-[#eaedf5] text-[#3f4e7a]')}><Icon size={16} /></span><span className={cn('size-2 rounded-full', tone === 'red' ? 'bg-[#c86f5b]' : 'bg-[#6dc4a6]')} /></div><div className="mt-5 font-mono text-[9px] uppercase tracking-[.14em] text-[#9a9287]">{label}</div><div className="mt-1 truncate text-sm font-bold text-[#222b4b]">{value}</div></SectionCard>;
}

function PipelineRow({ index, label, status, detail }: { index: number; label: string; status: string; detail: string }) {
  const ready = status === 'ready';
  const fallback = status === 'fallback';
  return <div className="flex items-center gap-3 px-3 py-3"><span className="grid size-8 place-items-center rounded-lg bg-[#f1e7d4] font-mono text-[10px] text-[#9a9287]">0{index + 1}</span><span className="flex-1 text-sm font-semibold text-[#3a3c46]">{label}</span><span className="font-mono text-[9px] text-[#9a9287]">{detail}</span><span className={cn('flex items-center gap-1.5 rounded-full px-2.5 py-1 font-mono text-[9px] uppercase tracking-[.1em]', ready ? 'bg-[#edf8f3] text-[#28675e]' : fallback ? 'bg-[#fdf2d8] text-[#9b691d]' : status === 'pending' ? 'bg-[#f1e7d4] text-[#77736c]' : 'bg-[#fff1ec] text-[#a14b38]')}><i className={cn('size-1.5 rounded-full', ready ? 'bg-[#2f8f83]' : fallback ? 'bg-[#d39b38]' : 'bg-current')} />{status}</span></div>;
}

function LatencyPanel({ response }: { response: LearningResponse }) {
  const metrics = [['ASR', response.latency.asrMs], ['Translation', response.latency.translationMs], ['Retrieval', response.latency.retrievalMs], ['Pedagogy', response.latency.pedagogyMs], ['TTS', response.latency.ttsMs]] as const;
  const max = Math.max(...metrics.map(([, value]) => value), 1);
  return <div className="p-5"><div className="flex items-end justify-between"><div className="font-display text-4xl font-semibold tracking-[-.06em] text-[#222b4b]">{response.latency.totalMs}<span className="ml-1 text-base font-medium text-[#9a9287]">ms</span></div><span className="font-mono text-[9px] uppercase tracking-[.13em] text-[#2f8f83]">measured</span></div><div className="mt-6 space-y-3">{metrics.map(([label, value]) => <div key={label}><div className="mb-1 flex justify-between font-mono text-[9px] uppercase tracking-[.1em] text-[#77736c]"><span>{label}</span><span>{value} ms</span></div><div className="h-2 overflow-hidden rounded-full bg-[#f1e7d4]"><div className="h-full rounded-full bg-[#2f8f83] transition-all" style={{ width: `${Math.max(value / max * 100, 4)}%` }} /></div></div>)}</div></div>;
}

function SystemStatusPanel({ status, loading, error }: { status?: SystemStatusResponse; loading: boolean; error: boolean }) {
  const items = status ? [
    ['Translation', status.translation],
    ['ASR', status.asr],
    ['TTS', status.tts],
    ['LLM', status.llm],
    ['RAG', status.rag],
    ['Database', status.database],
  ] as const : [];
  return <SectionCard className="overflow-hidden"><div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#e5ddcf] px-5 py-4"><div><Eyebrow>Provider boundaries</Eyebrow><h2 className="mt-2 font-display text-xl font-semibold tracking-[-.04em] text-[#222b4b]">What is available right now</h2></div><span className="rounded-full bg-[#f1e7d4] px-2.5 py-1 font-mono text-[9px] uppercase tracking-[.13em] text-[#77736c]">{status?.mode ?? (loading ? 'checking' : error ? 'unavailable' : 'local mode')}</span></div>{loading ? <div className="grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-3">{[1, 2, 3, 4, 5, 6].map((item) => <div key={item} className="h-20 animate-pulse rounded-xl bg-[#f1e7d4]" />)}</div> : error ? <ErrorState text="System status could not be loaded; the learning flow can still use local curriculum data." /> : <div className="grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-3">{items.map(([label, item]) => <div key={label} className="rounded-xl border border-[#ded6c7] p-3"><div className="flex items-center justify-between gap-2"><span className="text-sm font-bold text-[#222b4b]">{label}</span><span className={cn('rounded-full px-2 py-1 font-mono text-[8px] uppercase tracking-[.1em]', item.status === 'available' ? 'bg-[#edf8f3] text-[#28675e]' : item.status === 'demo' ? 'bg-[#fdf2d8] text-[#9b691d]' : 'bg-[#fff1ec] text-[#a14b38]')}>{item.status}</span></div><p className="mt-2 text-[11px] leading-5 text-[#77736c]">{item.provider}</p></div>)}</div>}</SectionCard>;
}

function Router() {
  return <ErrorBoundaryWrapper><Shell><Switch><Route path="/" component={Home} /><Route path="/teacher" component={Teacher} /><Route path="/student" component={Student} /><Route path="/curriculum" component={Curriculum} /><Route path="/dashboard" component={Dashboard} /><Route component={NotFound} /></Switch></Shell></ErrorBoundaryWrapper>;
}

function ErrorBoundaryWrapper({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;