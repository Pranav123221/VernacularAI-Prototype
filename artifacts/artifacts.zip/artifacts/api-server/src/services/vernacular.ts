import fs from "node:fs";
import path from "node:path";

type Source = {
  publisher: string;
  label: string;
  grade: number;
  subject: string;
  chapter: string;
  page: string;
};

export type Chunk = {
  id: string;
  text: string;
  score: number;
  metadata: Source;
};

type CurriculumFile = {
  id: string;
  grade: number;
  subject: string;
  chapter: string;
  page: string;
  directory: string;
  fileName: string;
  text: string;
};

type Chapter = CurriculumFile & {
  source: string;
  chunkCount: number;
  indexed: boolean;
  excerpt: string;
  originalText: string;
  chunks: Chunk[];
};

const curriculumFiles: CurriculumFile[] = [
  {
    id: "plants-sunlight",
    grade: 3,
    subject: "evs",
    chapter: "Plants and Sunlight",
    page: "12–13",
    directory: "grade_3/evs",
    fileName: "plants-sunlight.txt",
    text: `Plants need sunlight, air, water, and space to grow. Sunlight gives green leaves energy to make food for the plant.

Roots take in water from the soil. The stem holds the plant up and carries water to different parts. Leaves use sunlight, air, and water to help the plant make food.

We can observe this by keeping one small plant in sunlight and another in a dark cupboard. The plant with sunlight stays greener and stronger. Plants also give us fruits, vegetables, shade, and clean air.

Teacher prompt: Ask children to name a plant near their home and point to its roots, stem, and leaves.`,
  },
  {
    id: "plants-around-us",
    grade: 3,
    subject: "evs",
    chapter: "Plants Around Us",
    page: "14–15",
    directory: "grade_3/evs",
    fileName: "plants-around-us.txt",
    text: `Plants grow in many places. Some plants are herbs with soft stems, while others have hard woody stems. Trees, shrubs, herbs, climbers, and creepers are plants we can notice around us.

People use plants for food, medicine, shade, wood, and many other things. We should care for plants by giving them water, protecting young plants, and avoiding harm to living branches.`,
  },
  {
    id: "numbers-1-to-10",
    grade: 1,
    subject: "mathematics",
    chapter: "Numbers 1 to 10",
    page: "1–2",
    directory: "grade_1/mathematics",
    fileName: "numbers.txt",
    text: `Children learn to recognize numbers from 1 to 10 and say them in order. Counting means matching one number word to one object. When we count a group, the last number we say tells us how many objects are in the group.

We can count familiar things such as seeds, stones, sticks, fruits, or pencils. The number 1 means one object. The number 2 means two objects. The number 3 means three objects. The numbers continue in order: 4, 5, 6, 7, 8, 9, and 10.

A number line helps us see order. The number after 3 is 4. The number before 6 is 5. We can compare small groups by counting each group. A group with more objects has a bigger number.

Teacher prompt: Encourage children to touch or move each object once while saying one number word. Ask children to show the number of objects with their fingers.`,
  },
  {
    id: "shapes-around-us",
    grade: 1,
    subject: "mathematics",
    chapter: "Shapes Around Us",
    page: "3–4",
    directory: "grade_1/mathematics",
    fileName: "shapes.txt",
    text: `We see shapes around us. A circle is round like a plate. A square has four equal sides like a small tile. A triangle has three sides. We can find and name shapes in objects we use every day.

Children can draw shapes with a finger in the air, trace them on paper, and look for the same shape in their classroom. Talking about sides and corners helps children notice how shapes are different.`,
  },
];

const sourceFor = (chapter: CurriculumFile): Source => ({
  publisher: "VernacularAI",
  label: `NCERT Grade ${chapter.grade} ${chapter.subject.toUpperCase()}-aligned demo passage`,
  grade: chapter.grade,
  subject: chapter.subject,
  chapter: chapter.chapter,
  page: chapter.page,
});

const normalize = (value: string) =>
  value
    .toLocaleLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter((token) => token.length > 1);

const vectorize = (value: string) => {
  const counts = new Map<string, number>();
  for (const token of normalize(value)) counts.set(token, (counts.get(token) ?? 0) + 1);
  return counts;
};

const cosineSimilarity = (left: Map<string, number>, right: Map<string, number>) => {
  let dot = 0;
  let leftMagnitude = 0;
  let rightMagnitude = 0;
  for (const value of left.values()) leftMagnitude += value * value;
  for (const value of right.values()) rightMagnitude += value * value;
  for (const [token, value] of left) dot += value * (right.get(token) ?? 0);
  if (!leftMagnitude || !rightMagnitude) return 0;
  return dot / Math.sqrt(leftMagnitude * rightMagnitude);
};

const loadText = (chapter: CurriculumFile) => {
  const filePath = path.resolve(process.cwd(), "data", "curriculum", chapter.directory, chapter.fileName);
  try {
    return fs.readFileSync(filePath, "utf8")
      .split("\n")
      .filter((line) => !line.startsWith("VernacularAI") && !line.startsWith("Source note:"))
      .join("\n")
      .trim();
  } catch {
    return chapter.text;
  }
};

const splitIntoChunks = (chapter: CurriculumFile, text: string): Chunk[] =>
  text.split(/\n\s*\n/).map((item) => item.trim()).filter(Boolean).map((paragraph, index) => ({
    id: `${chapter.id}-${index + 1}`,
    text: paragraph,
    score: 0,
    metadata: { ...sourceFor(chapter), page: `${Number(chapter.page.split("–")[0]) + index}` },
  }));

export const chapters: Chapter[] = curriculumFiles.map((chapter) => {
  const originalText = loadText(chapter);
  const chunks = splitIntoChunks(chapter, originalText);
  return {
    ...chapter,
    source: "VernacularAI curated curriculum sample",
    chunkCount: chunks.length,
    indexed: true,
    excerpt: chunks[0]?.text ?? "",
    originalText,
    chunks,
  };
});

export function listChapters() {
  return chapters.map(({ originalText: _originalText, chunks: _chunks, text: _text, directory: _directory, fileName: _fileName, page: _page, ...chapter }) => chapter);
}

export function getChapter(id: string) {
  return chapters.find((chapter) => chapter.id === id);
}

export function retrieve(question: string, chapterId?: string | null) {
  const pool = chapterId ? chapters.filter((chapter) => chapter.id === chapterId) : chapters;
  const queryVector = vectorize(question);
  return pool
    .flatMap((chapter) => chapter.chunks)
    .map((chunk) => ({ ...chunk, score: Number(cosineSimilarity(queryVector, vectorize(chunk.text)).toFixed(3)) }))
    .sort((left, right) => right.score - left.score)
    .filter((chunk) => chunk.score > 0)
    .slice(0, 3);
}

const hasAny = (question: string, words: string[]) =>
  words.some((word) => normalize(question).includes(word));

export function translateToSantali(text: string) {
  const phrase = text.trim();
  const replacements: Array<[RegExp, string]> = [
    [/पौधों|पौधे|पौधा/g, "ᱡᱟᱹᱛᱤ"],
    [/सूरज|सूर्य|धूप|रोशनी/g, "ᱥᱮᱛᱟᱜ"],
    [/पानी|जल/g, "ᱫᱟᱜ"],
    [/जड़/g, "ᱡᱟᱹᱲ"],
    [/तना/g, "ᱫᱟᱲᱮ"],
    [/पत्ते|पत्तियाँ|पत्ती/g, "ᱥᱟᱠᱟᱢ"],
    [/संख्या|नंबर/g, "संख्या"],
    [/गिनती/g, "गिनती"],
    [/सीख/g, "सेल"],
    [/पहचान/g, "ओलोक"],
    [/बच्चों/g, "पानते"],
    [/एक/g, "मित"],
    [/दो/g, "बार"],
    [/तीन/g, "पे"],
    [/चार/g, "पोन"],
    [/पाँच/g, "मोड़"],
    [/उदाहरण/g, "नमूना"],
  ];
  let output = phrase;
  for (const [pattern, replacement] of replacements) output = output.replace(pattern, replacement);
  return output === phrase ? `ᱱᱟᱢᱵᱟᱨ ᱥᱮᱫ ᱟᱠᱟᱱᱟ: ${phrase}` : `ᱥᱟᱱᱛᱟᱲᱤ: ${output}`;
}

export function buildPedagogy(question: string, sources: Chunk[]) {
  const plantTopic = hasAny(question, ["पौधा", "पौधे", "पौधों", "सूरज", "सूर्य", "धूप", "रोशनी", "plants", "sunlight"]) || sources.some((chunk) => chunk.id.startsWith("plants"));
  const numbersTopic = hasAny(question, ["गिनती", "संख्या", "नंबर", "count", "number"]);
  const shapesTopic = hasAny(question, ["आकार", "shape", "गोल", "त्रिभुज", "वर्ग"]);
  if (plantTopic) {
    return {
      answer: "पौधों को सूरज की रोशनी चाहिए क्योंकि पत्तियाँ रोशनी, हवा और पानी की मदद से पौधे के लिए भोजन बनाती हैं।",
      example: "जैसे हमें खाना खाने से ऊर्जा मिलती है, वैसे ही पौधे अपनी पत्तियों में सूरज की रोशनी से भोजन बनाते हैं।",
      keyPoints: ["सूरज की रोशनी पत्तियों को भोजन बनाने में मदद करती है।", "जड़ें मिट्टी से पानी लेती हैं।", "पौधों को हवा और पानी भी चाहिए।"],
      quiz: [
        { question: "पौधों को भोजन बनाने में किसकी मदद मिलती है?", options: ["सूरज की रोशनी", "पत्थर", "खिलौना"], answer: "सूरज की रोशनी" },
        { question: "जड़ें मिट्टी से क्या लेती हैं?", options: ["पानी", "धूप", "कागज"], answer: "पानी" },
        { question: "पौधे की कौन-सी भाग में भोजन बनता है?", options: ["पत्तियाँ", "जूते", "पत्थर"], answer: "पत्तियाँ" },
      ],
    };
  }
  if (numbersTopic || (!shapesTopic && sources.some((chunk) => chunk.id.startsWith("numbers")))) {
    return {
      answer: "गिनती में हम हर वस्तु को एक बार छूकर एक संख्या बोलते हैं। 1 से 10 तक संख्याएँ क्रम में आती हैं। आखिरी बोली गई संख्या बताती है कि हमारे पास कितनी वस्तुएँ हैं।",
      example: "अगर हमारे पास 3 बीज हैं, तो हम बोलेंगे: 1, 2, 3। इसलिए हमारे पास तीन बीज हैं।",
      keyPoints: ["1 से 10 तक संख्याओं को क्रम में बोलें।", "हर वस्तु के लिए एक संख्या बोलें।", "आखिरी संख्या कुल वस्तुओं की संख्या बताती है।"],
      quiz: [
        { question: "3 के बाद कौन-सी संख्या आती है?", options: ["2", "4", "5"], answer: "4" },
        { question: "दो पेंसिल दिखाने के लिए कौन-सी संख्या सही है?", options: ["1", "2", "6"], answer: "2" },
        { question: "गिनती में हर वस्तु को कितनी बार छूना चाहिए?", options: ["एक बार", "तीन बार", "बिना छुए"], answer: "एक बार" },
      ],
    };
  }
  return {
    answer: "आकार हमारे आसपास की वस्तुओं को पहचानने में मदद करते हैं। वृत्त गोल होता है, वर्ग की चार बराबर भुजाएँ होती हैं और त्रिभुज की तीन भुजाएँ होती हैं।",
    example: "प्लेट को देखिए। उसका आकार वृत्त जैसा गोल है।",
    keyPoints: ["वृत्त गोल होता है।", "वर्ग की चार बराबर भुजाएँ होती हैं।", "त्रिभुज की तीन भुजाएँ होती हैं।"],
    quiz: [
      { question: "किस आकार की तीन भुजाएँ होती हैं?", options: ["वृत्त", "वर्ग", "त्रिभुज"], answer: "त्रिभुज" },
      { question: "प्लेट किस आकार जैसी दिख सकती है?", options: ["वृत्त", "त्रिभुज", "वर्ग"], answer: "वृत्त" },
      { question: "वर्ग की कितनी बराबर भुजाएँ होती हैं?", options: ["3", "4", "5"], answer: "4" },
    ],
  };
}