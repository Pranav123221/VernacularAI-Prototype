import { Router, type IRouter, type Request, type Response } from "express";
import { sql } from "drizzle-orm";
import {
  AskLearningQuestionBody,
  AskLearningQuestionResponse,
  GenerateLessonBody,
  GenerateLessonResponse,
  GenerateQuizBody,
  GenerateQuizResponse,
  GetCurriculumChapterParams,
  GetCurriculumChapterResponse,
  GetMetricsResponse,
  GetSystemStatusResponse,
  ListCurriculumResponse,
  ListSourcesResponse,
  SubmitFeedbackBody,
  SubmitFeedbackResponse,
  SynthesizeSpeechBody,
  SynthesizeSpeechResponse,
  TranslateTextBody,
  TranslateTextResponse,
  TranscribeVoiceBody,
  TranscribeVoiceResponse,
} from "@workspace/api-zod";
import {
  buildPedagogy,
  chapters,
  getChapter,
  listChapters,
  retrieve,
  translateToSantali,
} from "../services/vernacular";

const router: IRouter = Router();
const nowMs = () => Number(process.hrtime.bigint() / BigInt(1_000_000));
let requests = 0;
let successfulRequests = 0;
let totalLatencyMs = 0;
let lastLatencyMs = 0;

const recordRequest = (latencyMs: number) => {
  successfulRequests += 1;
  totalLatencyMs += latencyMs;
  lastLatencyMs = latencyMs;
};

const providerStatus = (status: "available" | "unavailable" | "demo", provider: string, message: string) => ({
  status,
  provider,
  message,
});

router.get("/curriculum", (_req, res): void => {
  res.json(ListCurriculumResponse.parse(listChapters()));
});

router.get("/curriculum/:chapterId", (req, res): void => {
  const parsed = GetCurriculumChapterParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const chapter = getChapter(parsed.data.chapterId);
  if (!chapter) {
    res.status(404).json({ error: "Curriculum chapter not found" });
    return;
  }
  res.json(GetCurriculumChapterResponse.parse(chapter));
});

router.get("/sources", (_req, res): void => {
  res.json(ListSourcesResponse.parse(chapters.flatMap((chapter) => chapter.chunks)));
});

router.post("/ask", (req, res): void => {
  requests += 1;
  const startedAt = nowMs();
  const parsed = AskLearningQuestionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const data = parsed.data;
  const detectedLanguage = /[\u0900-\u097f]/u.test(data.question) ? "Hindi" : data.sourceLanguage === "en" ? "English" : "Hindi (selected)";
  const translationStarted = nowMs();
  const translatedQuestion = translateToSantali(data.question);
  const translationMs = nowMs() - translationStarted;
  const retrievalStarted = nowMs();
  const sources = retrieve(data.question, data.chapterId);
  const retrievalMs = nowMs() - retrievalStarted;
  if (!sources.length) {
    const totalMs = nowMs() - startedAt;
    recordRequest(totalMs);
    res.status(200).json(AskLearningQuestionResponse.parse({
      question: data.question,
      detectedLanguage,
      translatedQuestion,
      answer: "I could not find sufficient information in the approved curriculum content.",
      targetAnswer: "ᱥᱮᱞᱮᱫ ᱠᱟᱹᱢᱤ ᱨᱮ ᱱᱚᱣᱟ ᱥᱟᱦᱟᱭ ᱵᱟᱝ ᱢᱮᱱᱟᱜᱼᱟ।",
      example: "Try asking about a topic in one of the indexed chapters.",
      targetExample: "ᱱᱚᱣᱟ ᱵᱟᱵᱚᱛ ᱨᱮ ᱯᱩᱪᱷ ᱢᱮ ᱥᱮ ᱞᱟᱹᱭ ᱪᱮᱫ ᱠᱟᱛᱷᱟ ᱢᱮᱱᱟᱜᱼᱟ।",
      keyPoints: [],
      quiz: [],
      sources: [],
      latency: { asrMs: 0, translationMs, retrievalMs, pedagogyMs: 0, ttsMs: 0, totalMs },
      status: { languageDetection: "ready", translation: "fallback", rag: "ready", pedagogy: "unavailable", quiz: "unavailable", tts: "fallback" },
      voice: { available: false, provider: "Browser speech synthesis", message: "Voice output is handled by the device when supported." },
    }));
    return;
  }
  const pedagogyStarted = nowMs();
  const pedagogy = buildPedagogy(data.question, sources);
  const pedagogyMs = nowMs() - pedagogyStarted;
  const totalMs = nowMs() - startedAt;
  recordRequest(totalMs);
  res.json(AskLearningQuestionResponse.parse({
    question: data.question,
    detectedLanguage,
    translatedQuestion,
    answer: pedagogy.answer,
    targetAnswer: translateToSantali(pedagogy.answer),
    example: pedagogy.example,
    targetExample: translateToSantali(pedagogy.example),
    keyPoints: pedagogy.keyPoints,
    quiz: pedagogy.quiz,
    sources,
    latency: { asrMs: 0, translationMs, retrievalMs, pedagogyMs, ttsMs: 0, totalMs },
    status: { languageDetection: "ready", translation: "fallback", rag: "ready", pedagogy: "fallback", quiz: "fallback", tts: "fallback" },
    voice: { available: false, provider: "Browser speech synthesis", message: "Use the play button to speak this answer on supported devices." },
  }));
});

router.post("/translate", (req, res): void => {
  const parsed = TranslateTextBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const startedAt = nowMs();
  const translatedText = translateToSantali(parsed.data.text);
  res.json(TranslateTextResponse.parse({
    translatedText,
    provider: "Local phrasebook fallback",
    status: "fallback",
    latencyMs: nowMs() - startedAt,
  }));
});

router.post("/quiz", (req, res): void => {
  const parsed = GenerateQuizBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const sources = retrieve(parsed.data.question, parsed.data.chapterId);
  if (!sources.length) {
    res.json(GenerateQuizResponse.parse({ quiz: [], status: "unavailable" }));
    return;
  }
  res.json(GenerateQuizResponse.parse({ quiz: buildPedagogy(parsed.data.question, sources).quiz, status: "fallback" }));
});

const generateLesson = (req: Request, res: Response): void => {
  const startedAt = nowMs();
  const parsed = GenerateLessonBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const translationStarted = nowMs();
  const translatedLesson = translateToSantali(parsed.data.content);
  const translationMs = nowMs() - translationStarted;
  const retrievalStarted = nowMs();
  const sources = retrieve(parsed.data.content, parsed.data.chapterId);
  const retrievalMs = nowMs() - retrievalStarted;
  if (!sources.length) {
    res.status(400).json({ error: "No matching curriculum context found for this lesson." });
    return;
  }
  const pedagogyStarted = nowMs();
  const pedagogy = buildPedagogy(parsed.data.content, sources);
  const pedagogyMs = nowMs() - pedagogyStarted;
  const plantLesson = sources.some((source) => source.id.startsWith("plants"));
  const totalMs = nowMs() - startedAt;
  recordRequest(totalMs);
  res.json(GenerateLessonResponse.parse({
    title: plantLesson ? "Why plants need sunlight" : "Numbers and shapes through familiar objects",
    translatedLesson,
    explanation: pedagogy.answer,
    example: pedagogy.example,
    worksheet: plantLesson
      ? ["Draw a plant and label its roots, stem, and leaves.", "Place two similar plants in different light and observe them for three days."]
      : ["Draw 5 dots and count them.", "Circle the number that comes after 3: 2, 4, 6."],
    flashcards: plantLesson
      ? [{ front: "पौधों को सूरज की रोशनी क्यों चाहिए?", back: "पत्तियाँ पौधे के लिए भोजन बनाती हैं।" }, { front: "जड़ें क्या लेती हैं?", back: "मिट्टी से पानी।" }]
      : [{ front: "3 के बाद?", back: "4" }, { front: "तीन भुजाओं वाला आकार?", back: "त्रिभुज" }],
    quiz: pedagogy.quiz,
    sources,
    latency: { asrMs: 0, translationMs, retrievalMs, pedagogyMs, ttsMs: 0, totalMs },
  }));
};

router.post("/lesson/generate", generateLesson);
router.post("/generate-lesson", generateLesson);

router.post("/asr", (req, res): void => {
  const parsed = TranscribeVoiceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  res.json(TranscribeVoiceResponse.parse({
    available: false,
    provider: "IndicConformer (not installed)",
    transcript: null,
    message: "Voice model unavailable in current environment — use text input.",
    latencyMs: 0,
  }));
});

router.post("/tts", (req, res): void => {
  const parsed = SynthesizeSpeechBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  res.json(SynthesizeSpeechResponse.parse({
    available: false,
    provider: "IndicF5 / Indic-TTS (not installed)",
    audioUrl: null,
    message: "Server audio is unavailable; browser speech synthesis may be used when supported.",
    latencyMs: 0,
  }));
});

router.get("/system-status", async (req, res): Promise<void> => {
  let database = providerStatus("unavailable", "PostgreSQL", "Database connection is not available.");
  try {
    const { db } = await import("@workspace/db");
    await db.execute(sql`select 1`);
    database = providerStatus("available", "PostgreSQL", "Development database is connected.");
  } catch (error) {
    req.log.warn({ error }, "Database status check failed");
  }
  res.json(GetSystemStatusResponse.parse({
    mode: "Local / Demo Mode",
    translation: providerStatus("demo", "Local phrasebook fallback", "Santali bridge is available as a labeled development fallback."),
    asr: providerStatus("unavailable", "IndicConformer", "Voice model unavailable in current environment — use text input."),
    tts: providerStatus("unavailable", "IndicF5 / Indic-TTS", "No server audio model installed; browser speech synthesis may still work."),
    llm: providerStatus("demo", "Local pedagogical fallback", "Structured explanations use retrieved curriculum context without an external API."),
    rag: providerStatus("available", "Local cosine retrieval", `${chapters.reduce((sum, chapter) => sum + chapter.chunkCount, 0)} curriculum chunks indexed locally.`),
    database,
  }));
});

router.get("/metrics", (_req, res): void => {
  res.json(GetMetricsResponse.parse({
    requests,
    successfulRequests,
    averageLatencyMs: successfulRequests ? Number((totalLatencyMs / successfulRequests).toFixed(2)) : 0,
    lastLatencyMs,
    curriculumChunks: chapters.reduce((sum, chapter) => sum + chapter.chunkCount, 0),
  }));
});

router.post("/feedback", async (req, res): Promise<void> => {
  const parsed = SubmitFeedbackBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const createdAt = new Date().toISOString();
  let id = `feedback-${Date.now()}`;
  try {
    const { db, feedbackTable } = await import("@workspace/db");
    const [saved] = await db.insert(feedbackTable).values({
      helpful: parsed.data.helpful ? "true" : "false",
      question: parsed.data.question ?? null,
      targetLanguage: parsed.data.targetLanguage ?? null,
    }).returning({ id: feedbackTable.id });
    id = String(saved.id);
  } catch (error) {
    req.log.warn({ error }, "Feedback persistence unavailable; returning accepted in-memory feedback");
  }
  res.status(201).json(SubmitFeedbackResponse.parse({ id, helpful: parsed.data.helpful, createdAt }));
});

export default router;