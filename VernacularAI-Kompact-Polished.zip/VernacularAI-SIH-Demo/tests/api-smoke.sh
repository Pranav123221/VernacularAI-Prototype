#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${VERNACULAR_API_URL:-http://localhost:8080}"
json() { curl -fsS "$@"; }

test "$(json "$BASE_URL/api/health" | jq -r .status)" = "ok"
test "$(json "$BASE_URL/api/curriculum" | jq 'length')" -ge 1
test "$(json "$BASE_URL/api/sources" | jq 'length')" -ge 1

json -X POST "$BASE_URL/api/translate" \
  -H 'content-type: application/json' \
  --data '{"text":"Why do plants need sunlight?","sourceLanguage":"en","targetLanguage":"sat"}' \
  | jq -e '.translatedText and .status' >/dev/null

json -X POST "$BASE_URL/api/ask" \
  -H 'content-type: application/json' \
  --data '{"question":"Why do plants need sunlight?","sourceLanguage":"en","targetLanguage":"sat","grade":3,"subject":"evs","chapterId":"plants-sunlight"}' \
  | jq -e '.sources | length >= 1' >/dev/null

json -X POST "$BASE_URL/api/quiz" \
  -H 'content-type: application/json' \
  --data '{"question":"Why do plants need sunlight?","chapterId":"plants-sunlight"}' \
  | jq -e '.quiz | length == 3' >/dev/null

json -X POST "$BASE_URL/api/asr" \
  -H 'content-type: application/json' \
  --data '{"language":"hi"}' \
  | jq -e '.available == false and .transcript == null' >/dev/null

json -X POST "$BASE_URL/api/tts" \
  -H 'content-type: application/json' \
  --data '{"text":"पौधों को सूरज की रोशनी चाहिए।","targetLanguage":"sat"}' \
  | jq -e '.available == false and .audioUrl == null' >/dev/null

json "$BASE_URL/api/system-status" | jq -e '.mode and .rag.status' >/dev/null
json "$BASE_URL/api/metrics" | jq -e '.curriculumChunks >= 1' >/dev/null
echo "API smoke checks passed."