import { createInsertSchema } from "drizzle-zod";
import { integer, jsonb, real, serial, text, timestamp, pgTable } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const curriculumDocumentsTable = pgTable("curriculum_documents", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  publisher: text("publisher").notNull(),
  grade: integer("grade").notNull(),
  subject: text("subject").notNull(),
  chapter: text("chapter").notNull(),
  sourceLabel: text("source_label").notNull(),
  originalText: text("original_text").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const curriculumChunksTable = pgTable("curriculum_chunks", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").notNull(),
  chunkKey: text("chunk_key").notNull().unique(),
  text: text("text").notNull(),
  page: text("page").notNull(),
  embedding: jsonb("embedding"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const questionsTable = pgTable("questions", {
  id: serial("id").primaryKey(),
  question: text("question").notNull(),
  sourceLanguage: text("source_language").notNull(),
  targetLanguage: text("target_language").notNull(),
  grade: integer("grade").notNull(),
  subject: text("subject").notNull(),
  chapterId: text("chapter_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const responsesTable = pgTable("responses", {
  id: serial("id").primaryKey(),
  questionId: integer("question_id"),
  answer: text("answer").notNull(),
  targetAnswer: text("target_answer").notNull(),
  latencyMs: integer("latency_ms").notNull(),
  sourceIds: jsonb("source_ids").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const feedbackTable = pgTable("feedback", {
  id: serial("id").primaryKey(),
  helpful: text("helpful").notNull(),
  question: text("question"),
  targetLanguage: text("target_language"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertFeedbackSchema = createInsertSchema(feedbackTable).omit({
  id: true,
  createdAt: true,
});
export type InsertFeedback = z.infer<typeof insertFeedbackSchema>;
export type Feedback = typeof feedbackTable.$inferSelect;

export type CurriculumDocument = typeof curriculumDocumentsTable.$inferSelect;
export type CurriculumChunk = typeof curriculumChunksTable.$inferSelect;