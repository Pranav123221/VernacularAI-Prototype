"""Run honest smoke checks against the live VernacularAI API."""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from pathlib import Path


BASE_URL = os.environ.get("VERNACULAR_API_URL", "http://localhost:8080")


def post(path: str, payload: dict) -> dict:
    request = urllib.request.Request(
        f"{BASE_URL}{path}",
        data=json.dumps(payload).encode(),
        headers={"content-type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=5) as response:
        return json.load(response)


def main() -> int:
    questions = json.loads(Path(__file__).with_name("test_questions.json").read_text())
    failures: list[str] = []
    for item in questions:
        try:
            result = post("/api/ask", item)
        except (urllib.error.URLError, TimeoutError) as error:
            failures.append(f"{item['question']}: API unavailable ({error})")
            continue
        checks = {
            "sources": bool(result.get("sources")),
            "quiz_has_three": len(result.get("quiz", [])) == 3,
            "target_answer": bool(result.get("targetAnswer")),
            "measured_latency": isinstance(result.get("latency", {}).get("totalMs"), (int, float)),
        }
        failed = [name for name, passed in checks.items() if not passed]
        if failed:
            failures.append(f"{item['question']}: {', '.join(failed)}")
        else:
            print(f"PASS: {item['question']} ({result['latency']['totalMs']} ms)")

    if failures:
        for failure in failures:
            print(f"FAIL: {failure}")
        return 1
    print("All evaluation smoke checks passed. No accuracy claim is made.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())