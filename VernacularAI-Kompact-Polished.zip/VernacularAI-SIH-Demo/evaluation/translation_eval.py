"""Smoke-checks that the translation provider returns a target-language payload."""

import json
import urllib.request


def main() -> None:
    payload = json.dumps({
        "question": "तीन के बाद कौन सी संख्या आती है?",
        "sourceLanguage": "hi",
        "targetLanguage": "sat",
        "grade": 1,
        "subject": "mathematics",
    }).encode()
    request = urllib.request.Request("http://localhost:5000/api/ask", data=payload, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(request) as response:
        data = json.load(response)
    print({"translated_question": bool(data["translatedQuestion"]), "provider": data["status"]["translation"]})


if __name__ == "__main__":
    main()