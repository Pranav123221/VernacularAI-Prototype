"""Checks that a matched answer carries inspectable curriculum source chunks."""

import json
import urllib.request


def main() -> None:
    payload = json.dumps({
        "question": "आकारों के बारे में बताइए",
        "sourceLanguage": "hi",
        "targetLanguage": "sat",
        "grade": 1,
        "subject": "mathematics",
        "chapterId": "shapes-around-us",
    }).encode()
    request = urllib.request.Request("http://localhost:5000/api/ask", data=payload, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(request) as response:
        data = json.load(response)
    print({"has_sources": bool(data["sources"]), "source_ids": [source["id"] for source in data["sources"]]})


if __name__ == "__main__":
    main()