"""Smoke-check the curriculum retrieval endpoint without claiming benchmark scores."""

import json
import urllib.request


def main() -> None:
    payload = json.dumps({
        "question": "गिनती 1 से 10 तक कैसे सीखें?",
        "sourceLanguage": "hi",
        "targetLanguage": "sat",
        "grade": 1,
        "subject": "mathematics",
        "chapterId": "numbers-1-to-10",
    }).encode()
    request = urllib.request.Request("http://localhost:5000/api/ask", data=payload, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(request) as response:
        data = json.load(response)
    print({"source_count": len(data["sources"]), "grounded": data["status"]["rag"] == "ready"})


if __name__ == "__main__":
    main()