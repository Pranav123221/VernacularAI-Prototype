"""Prints measured latency from one end-to-end request."""

import json
import urllib.request


def main() -> None:
    payload = json.dumps({
        "question": "बच्चों को गिनती सिखाइए",
        "sourceLanguage": "hi",
        "targetLanguage": "sat",
        "grade": 1,
        "subject": "mathematics",
    }).encode()
    request = urllib.request.Request("http://localhost:5000/api/ask", data=payload, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(request) as response:
        data = json.load(response)
    print(data["latency"])


if __name__ == "__main__":
    main()