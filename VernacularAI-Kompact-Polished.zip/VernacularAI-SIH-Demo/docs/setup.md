# Setup

## Direct development

Prerequisites: Node 24, pnpm, and PostgreSQL with `DATABASE_URL`.

```bash
pnpm install
pnpm --filter @workspace/api-spec run codegen
pnpm --filter @workspace/db run push
pnpm --filter @workspace/api-server run dev
```

In a second terminal:

```bash
pnpm --filter @workspace/vernacular-ai run dev
```

The web app uses `/` and the API uses `/api`. In Replit, start the configured API and web workflows instead of running two terminals.

## Docker

```bash
docker compose up --build
```

Docker is optional. The local curriculum and deterministic provider path do not require network access or model downloads.

## Environment

Copy `.env.example` to `.env` for local work. `DATABASE_URL` is required for PostgreSQL persistence; the learning pipeline itself uses bundled files and remains usable if feedback storage is unavailable.