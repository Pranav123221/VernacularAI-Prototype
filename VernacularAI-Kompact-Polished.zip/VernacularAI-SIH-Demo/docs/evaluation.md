# Evaluation

The repository includes smoke evaluators, not benchmark claims:

```bash
python evaluation/evaluate.py
python evaluation/retrieval_eval.py
python evaluation/translation_eval.py
python evaluation/latency_eval.py
python evaluation/grounding_eval.py
```

`evaluate.py` calls the running API with the questions in `evaluation/test_questions.json` and reports whether each question returns curriculum sources, a three-question quiz, a target-language field, and measured latency. A failed check is reported as a failure; no accuracy percentage is invented.