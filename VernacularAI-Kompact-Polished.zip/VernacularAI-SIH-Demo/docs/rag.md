# Curriculum RAG

1. Original or authorized text is placed under `data/curriculum/`.
2. Startup ingestion reads the files and removes the short metadata header.
3. Each paragraph becomes a chunk with chapter, grade, subject, page, and source metadata.
4. The local provider tokenizes each question and chunk, creates count vectors, computes cosine similarity, filters zero matches, and returns the top three chunks.
5. Pedagogical generation receives the retrieved chunks and selects a grade-appropriate explanation template grounded in that context.
6. The API returns every selected chunk and score so the judge can inspect the grounding path.

The current samples are original curriculum-aligned passages and are not copied NCERT textbook pages. The source label identifies the relevant NCERT-aligned demo scope without misrepresenting the sample as official textbook text.

Use `python scripts/ingest_curriculum.py --help` to normalize an authorized text file into the expected data layout.