# Hackathon polish notes

This update keeps the existing VernacularAI workspace and makes the prototype's current capabilities clearer during a live demo.

## Changes in this pass

- The Student Learning answer panel explicitly labels the target-language output as a phrasebook demo preview.
- The UI states that Santali output has not yet been validated by native speakers.
- The voice playback now reads the Hindi explanation with the Hindi browser voice, instead of attempting to read Ol Chiki output with a Hindi voice.
- Voice playback labels now explain that Santali TTS is not connected yet.
- Retrieval score labels say `match` rather than implying a calibrated confidence probability.
- README capability notes now clearly distinguish browser Hindi TTS from the not-yet-integrated Santali TTS provider.

## Existing prototype limitations to preserve in the demo narrative

- Curriculum retrieval currently uses token-frequency vectors and cosine similarity, not a semantic embedding model.
- Hindi-to-Santali is a phrasebook fallback, not a validated general-purpose translation model.
- Pedagogical answers and quizzes are deterministic demo logic, not LLM-generated outputs.
- Browser speech recognition and speech synthesis depend on browser/device support.
- The current curriculum corpus contains curated demo passages aligned to primary topics; do not present them as verbatim official NCERT content.

## Suggested next engineering milestones

1. Add automated tests for retrieval relevance, no-context behavior, and lesson generation.
2. Add a reviewed Santali phrase/translation set with native-speaker validation.
3. Integrate a real Indic translation provider behind the current provider boundary.
4. Add a semantic embedding provider and evaluate top-k retrieval against a small question set.
5. Add language-appropriate TTS only after confirming support and validating pronunciation.
6. Benchmark each stage and end-to-end latency across repeated runs before making performance claims.
