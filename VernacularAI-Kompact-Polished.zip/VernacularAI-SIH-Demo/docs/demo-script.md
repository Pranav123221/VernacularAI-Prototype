# SIH demo script

1. Open VernacularAI and choose **Teacher mode**.
2. Confirm **Class 3**, **Environmental Studies**, **Santali**, and **Plants and Sunlight**.
3. Keep or enter: **Why do plants need sunlight?**
4. Generate the lesson pack.
5. Point to the original lesson input, translated lesson, explanation, worksheet, flashcards, and three-question quiz.
6. Open the displayed source cards and identify the retrieved curriculum chunks.
7. Open **How VernacularAI knows** in the Demo console.
8. Show the pipeline trace, provider availability, and measured latency.
9. Open Student mode and submit the same question. Use the microphone only when the browser reports it is available; otherwise demonstrate the typed fallback.
10. Play the answer using device speech synthesis when supported. Do not claim that server TTS or IndicF5 is installed.