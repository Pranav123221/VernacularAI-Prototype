# References

- Smart India Hackathon problem statement SIH26042: AI-Powered Vernacular Pedagogy and Real-Time Translation Tool for Mother Tongue-Based Primary Education.
- National Education Policy 2020: https://www.education.gov.in/nep/
- NCERT textbook portal: https://www.ncert.nic.in/textbook.php
- AI4Bharat IndicTrans2: https://github.com/AI4Bharat/IndicTrans2
- AI4Bharat models portal: https://models.ai4bharat.org/
- AI4Bharat IndicConformer references: https://models.ai4bharat.org/
- AI4Bharat IndicLID references: https://github.com/AI4Bharat/IndicLID
- AI4Bharat IndicF5: https://github.com/AI4Bharat/IndicF5
- Lewis et al., Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks: https://arxiv.org/abs/2005.11401

Model licenses, Hugging Face access requirements, and redistribution terms must be reviewed against the exact model checkpoint selected before shipping a production build. The included prototype does not bundle those model weights.