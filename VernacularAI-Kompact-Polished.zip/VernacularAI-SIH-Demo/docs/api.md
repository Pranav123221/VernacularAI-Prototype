# API documentation

All endpoints are served under `/api`.

## Ask

```http
POST /api/ask
Content-Type: application/json
```

```json
{
  "question": "बच्चों को 1 से 10 तक की संख्याएँ पहचानना और गिनना सीखना है।",
  "sourceLanguage": "hi",
  "targetLanguage": "sat",
  "grade": 1,
  "subject": "mathematics",
  "chapterId": "numbers-1-to-10"
}
```

The response includes bilingual text, quiz questions, retrieved source chunks, status for each pipeline stage, and measured latency fields.

## Curriculum

`GET /api/curriculum` returns the chapter catalog. `GET /api/curriculum/:chapterId` returns original demo text plus indexed chunks and metadata.

## Lesson generation

`POST /api/lesson/generate` accepts the same context fields and a `content` string, then returns a teacher-ready translated lesson, worksheet prompts, flashcards, quiz, and source chunks.

## Feedback

`POST /api/feedback` accepts `{ "helpful": true, "question": "...", "targetLanguage": "sat" }`.

The OpenAPI contract is the source of truth. Run `pnpm --filter @workspace/api-spec run codegen` after changing it.