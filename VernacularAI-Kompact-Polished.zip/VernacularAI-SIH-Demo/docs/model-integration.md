# Model integration boundaries

VernacularAI keeps each model concern behind a replaceable provider boundary:

| Capability | Current provider | Status | Upgrade path |
|---|---|---|---|
| Translation | Local phrasebook | Demo fallback | IndicTrans2 |
| Language detection | Unicode/script check | Available | IndicLID |
| Retrieval embeddings | Token vectors + cosine similarity | Local/available | Multilingual embedding model or pgvector |
| Pedagogy/LLM | Retrieved-context rule/template provider | Local/Demo Mode | Local LLM or optional API provider |
| ASR | Browser SpeechRecognition | Device-dependent | IndicConformer ASR |
| TTS | Browser speechSynthesis | Device-dependent | IndicF5 / Indic-TTS |

Large models are never downloaded at startup. A future provider must expose availability and failure state, preserve the response contract, and never silently substitute unsupported model output. The `/api/system-status`, `/api/asr`, and `/api/tts` endpoints make unavailable server providers explicit.