# VernacularAI architecture

## Provider boundaries

The MVP keeps each model concern replaceable:

- **Language detection**: a small script-aware detector for the demo, with an IndicLID adapter as the production option.
- **Translation**: the offline provider is a labeled, deterministic phrasebook fallback. IndicTrans2 should be added behind this boundary after model and license review.
- **Retrieval**: the demo uses local token vectors and cosine similarity so it can run on CPU and remain transparent. A multilingual embedding provider and pgvector index can replace it without changing the learning API.
- **Pedagogy**: the deterministic provider uses retrieved chunks plus age-appropriate topic rules for Grade 3 EVS and Grade 1 Mathematics. An API or local LLM provider can be connected with structured JSON output, but it must receive only retrieved context.
- **ASR**: the browser can provide SpeechRecognition. IndicConformer is the model path for a production server/mobile adapter.
- **TTS**: the browser can provide speechSynthesis. IndicF5 or an Indic TTS service is the production adapter.

## Grounding rule

`POST /api/ask` retrieves chunks first. If there are no positive-similarity chunks, it returns a clear no-match message and an empty quiz rather than generating an unsupported answer. Every success response contains the chunk text, score, and source metadata for inspection.

## Offline behavior

Curriculum files and their lightweight vectors are process-local and do not require a network round trip after startup. The frontend caches the last successful response in local storage for a degraded reading experience. Translation and pedagogy are labeled fallbacks in this MVP; ASR/TTS only claim ready status when the browser or a future provider is actually available.

## Data model

PostgreSQL schema tables:

- `curriculum_documents`
- `curriculum_chunks`
- `questions`
- `responses`
- `feedback`

Feedback is persisted when PostgreSQL is available. A database outage does not turn a read-only lesson into a false success; feedback is accepted with an explicit structured warning and the rest of the learning flow remains usable.