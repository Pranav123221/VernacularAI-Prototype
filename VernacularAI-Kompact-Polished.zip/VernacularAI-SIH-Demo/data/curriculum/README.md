# Curriculum data

The files in this folder are small, original, curriculum-aligned demonstration passages. They are intentionally not copied from NCERT textbooks. Each passage is split into searchable chunks at startup and surfaced with source metadata in the app so the judge can inspect the grounding path.