---
name: OpenAPI and Zod compatibility
description: The workspace currently generates Zod v3 schemas from OpenAPI contracts.
---

When adding integer-like fields to OpenAPI in this workspace, prefer `type: number` with numeric bounds unless the generator configuration is explicitly upgraded to a Zod version that supports `z.int()`.

**Why:** The current Orval output emits `zod.int()` for OpenAPI `integer`, while the installed Zod runtime is v3 and has no top-level `int` helper; codegen succeeds but the library typecheck fails.

**How to apply:** Keep integer semantics at the application/database boundary with explicit validation when needed, and rerun API codegen plus the library typecheck after contract changes.