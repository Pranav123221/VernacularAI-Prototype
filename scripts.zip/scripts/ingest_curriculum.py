#!/usr/bin/env python3
"""Normalize an authorized text curriculum file into VernacularAI's data layout."""

from __future__ import annotations

import argparse
import re
from pathlib import Path


def slug(value: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9]+", "-", value.strip().lower()).strip("-")
    if not cleaned:
        raise ValueError("chapter must contain letters or numbers")
    return cleaned


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path, help="Authorized .txt or .md source file")
    parser.add_argument("--grade", type=int, required=True, choices=range(1, 6))
    parser.add_argument("--subject", required=True, help="Subject slug, for example evs")
    parser.add_argument("--chapter", required=True, help="Chapter slug or title")
    parser.add_argument("--output-root", type=Path, default=Path("data/curriculum"))
    args = parser.parse_args()

    if args.source.suffix.lower() not in {".txt", ".md"}:
        raise SystemExit("Only authorized .txt and .md files are supported; convert PDFs after review.")
    if not args.source.is_file():
        raise SystemExit(f"Source file does not exist: {args.source}")
    if args.source.stat().st_size > 10 * 1024 * 1024:
        raise SystemExit("Refusing files larger than 10 MiB.")

    text = args.source.read_text(encoding="utf-8").strip()
    if not text:
        raise SystemExit("Source file is empty.")

    destination = args.output_root / f"grade_{args.grade}" / slug(args.subject)
    destination.mkdir(parents=True, exist_ok=True)
    output = destination / f"{slug(args.chapter)}.txt"
    header = (
        "VernacularAI authorized curriculum ingest\n"
        f"Source file: {args.source.name}\n"
        f"Grade: {args.grade}\n"
        f"Subject: {args.subject}\n"
        f"Chapter: {args.chapter}\n\n"
    )
    output.write_text(header + text + "\n", encoding="utf-8")
    print(f"Ingested {args.source} -> {output}")


if __name__ == "__main__":
    main()