"""Optional model setup placeholder.

The MVP intentionally does not download multi-gigabyte models at server startup.
Install an exact, license-reviewed checkpoint here when enabling IndicTrans2,
IndicConformer, IndicLID, IndicF5, or an LLM provider.
"""

from pathlib import Path


def main() -> None:
    model_dir = Path("models")
    model_dir.mkdir(exist_ok=True)
    print("No model weights are downloaded by the MVP.")
    print(f"Model cache directory is ready: {model_dir.resolve()}")
    print("Add a reviewed provider-specific download command before enabling production models.")


if __name__ == "__main__":
    main()